"""
Recolours the Samehada texture (from tools/source_art/samehada.glb) into tools/source_art/samehada_recolor.png,
which convert_models.py uses instead of the model's own texture:
  - the scales: shark-skin blue with a scale pattern (each spike picks up a different shade), instead of flat grey
  - the bandages: warm off-white cloth
  - the grip wrap: dark blue, matching the scales
The mouth (pink), teeth and skull pommel keep their colours. Run: python3 tools/recolor_samehada.py
"""
import io
import math
import os
import random

import pygltflib
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art", "samehada.glb")
OUT = os.path.join(HERE, "source_art", "samehada_recolor.png")

SCALE_DARK, SCALE_MID, SCALE_LIGHT = (30, 52, 92), (62, 98, 148), (128, 168, 210)
CLOTH = (236, 231, 216)
WRAP, WRAP_LIGHT = (40, 56, 88), (64, 84, 122)


def source_texture():
    gltf = pygltflib.GLTF2().load(SRC)
    blob = gltf.binary_blob()
    view = gltf.bufferViews[gltf.images[0].bufferView]
    return Image.open(io.BytesIO(blob[view.byteOffset or 0:(view.byteOffset or 0) + view.byteLength])).convert("RGBA")


def mix(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def close(c, ref, tol=26):
    return sum(abs(c[i] - ref[i]) for i in range(3)) <= tol


def scale_color(x, y, rng):
    """Overlapping fish scales, 10 px wide: lighter at each scale's top, darker toward its rim."""
    size = 10
    row = y // (size // 2)
    ox = (size // 2) if row % 2 else 0
    cx = ((x + ox) // size) * size - ox + size / 2
    cy = row * (size // 2) + size / 2
    d = math.hypot(x - cx, (y - cy) * 1.3) / (size * 0.62)
    t = min(1.0, d)
    base = mix(SCALE_LIGHT, SCALE_MID, min(1.0, t * 1.4)) if t < 0.7 else mix(SCALE_MID, SCALE_DARK, (t - 0.7) / 0.3)
    n = rng.randint(-8, 8)
    return tuple(max(0, min(255, v + n)) for v in base)


def main():
    src = source_texture()
    out = src.copy()
    rng = random.Random(7)
    px, po = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = px[x, y]
            c = (r, g, b)
            if close(c, (96, 96, 118)) or close(c, (95, 97, 113)):            # scales
                po[x, y] = scale_color(x, y, rng) + (a,)
            elif abs(r - 191) < 20 and abs(g - 167) < 20 and abs(b - 100) < 20:  # grip wrap (tan)
                t = ((x * 7 + y * 3) % 11) / 11
                po[x, y] = mix(WRAP, WRAP_LIGHT, t * 0.6) + (a,)
            elif close(c, (231, 231, 227)) or close(c, (223, 223, 223)):     # bandages
                n = rng.randint(-6, 4)
                po[x, y] = tuple(max(0, min(255, v + n)) for v in CLOTH) + (a,)
    out.save(OUT)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
