"""
Recolors the 3D scrolls by nature (Fire red, Water blue, Wind teal, Lightning yellow, Earth brown, Yin Yang black,
Ninjutsu purple; colors follow the nature chart; clan releases: Wood green, Ice pale blue, Magnet iron grey, Bone ivory,
Sealing crimson), and renders their inventory icons from the 3D model.
  - Jutsu scrolls: one color per release (the release the jutsu goes into). Only the green cloth changes.
  - Training scrolls: one color per nature. Only the purple cloth changes; the 地 label stays.
  - The blank scroll gets a rendered icon too.

Reads  textures/item/model/scroll_{jutsu,training,blank}_0.png and models/item/obj/scroll_*.obj
       (made by convert_models.py from scrolls.glb)
Writes textures/item/model/scroll_jutsu_<release>.png, scroll_training_<nature>.png
       textures/item/scroll_jutsu_<release>_icon.png, scroll_training_<nature>_icon.png, scroll_blank_icon.png
Run: python3 tools/recolor_scrolls.py
"""
import os

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
MODEL_TEX = os.path.join(ASSETS, "textures", "item", "model")
ICON_DIR = os.path.join(ASSETS, "textures", "item")
OBJ_DIR = os.path.join(ASSETS, "models", "item", "obj")

# release: (hue in degrees, saturation multiplier, brightness multiplier)
RELEASE_COLORS = {
    "fire": (5, 1.1, 1.15),
    "water": (212, 1.05, 1.2),
    "wind": (165, 0.55, 1.45),
    "lightning": (50, 1.1, 1.7),
    "earth": (28, 0.85, 0.95),
    "yin_yang": (0, 0.0, 0.6),
    "ninjutsu": (268, 0.9, 1.15),
    # clan releases
    "wood": (95, 0.8, 1.0),
    "ice": (190, 0.45, 1.6),
    "magnet": (220, 0.2, 0.75),
    "bone": (45, 0.25, 1.7),
    "sealing": (332, 0.85, 1.35),
}


def _hsv(rgb):
    mx, mn = rgb.max(-1), rgb.min(-1)
    d = mx - mn
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    sd = np.where(d > 1e-6, d, 1)
    h = np.where(mx == r, ((g - b) / sd) % 6, np.where(mx == g, (b - r) / sd + 2, (r - g) / sd + 4)) * 60
    h = np.where(d > 1e-6, h, 0)
    s = np.where(mx > 0, d / np.where(mx > 0, mx, 1), 0)
    return h, s, mx


def _rgb(h, s, v):
    hh = (h / 60) % 6
    i = np.floor(hh)
    f = hh - i
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    conds = [i == k for k in range(6)]
    return np.stack([np.select(conds, [v, q, p, p, t, v]), np.select(conds, [t, v, v, q, p, p]),
                     np.select(conds, [p, p, t, v, v, q])], -1)


# Training scroll cloth is purple, so it needs different strength to land on the same colors.
TRAINING_COLORS = {
    "fire": (5, 1.0, 1.25),
    "water": (212, 1.0, 1.25),
    "wind": (165, 0.6, 1.5),
    "lightning": (50, 1.0, 1.9),
    "earth": (28, 0.8, 1.05),
    "yin_yang": (0, 0.0, 0.62),
}


def recolor(img, hue, sat_mul, val_mul, src=(70, 170)):
    a = np.asarray(img.convert("RGBA"), dtype=np.float32) / 255
    h, s, v = _hsv(a[..., :3])
    cloth = (h > src[0]) & (h < src[1]) & (s > 0.2)  # only the cloth of the source color
    new = _rgb(np.full_like(h, hue), np.clip(s * sat_mul, 0, 1), np.clip(v * val_mul, 0, 1))
    rgb = np.where(cloth[..., None], new, a[..., :3])
    return Image.fromarray((np.concatenate([rgb, a[..., 3:]], -1) * 255).round().astype(np.uint8), "RGBA")


def load_obj(name):
    """Triangles of a converted OBJ, ready for convert_models.render()."""
    V, VT, tris = [], [], []
    for line in open(os.path.join(OBJ_DIR, name + ".obj")):
        t = line.split()
        if not t:
            continue
        if t[0] == "v":
            V.append([float(x) for x in t[1:4]])
        elif t[0] == "vt":
            VT.append([float(x) for x in t[1:3]])
        elif t[0] == "f":
            corners = [tuple(int(x) - 1 for x in c.split("/")) for c in t[1:]]
            v = np.array([V[c[0]] for c in corners])
            uv = np.array([VT[c[1]] for c in corners])
            n = np.cross(v[1] - v[0], v[2] - v[0])
            n = n / (np.linalg.norm(n) + 1e-9)
            tris.append((v, uv, np.array([n, n, n]), "tex0"))
    return tris


def icon(tris, texture):
    import convert_models as cm  # the same renderer and outline as the weapon icons
    pts = np.vstack([t[0] for t in tris])
    lo, hi = min(pts[:, 0].min(), pts[:, 1].min()), max(pts[:, 0].max(), pts[:, 1].max())
    pad = (hi - lo) * 0.04
    img = cm.render(tris, {"tex0": texture}, 256, lo - pad, hi + pad).resize((32, 32), Image.LANCZOS)
    return cm.outline_icon(img)


def main():
    import sys
    sys.path.insert(0, HERE)
    jutsu, training, blank = (Image.open(os.path.join(MODEL_TEX, f"scroll_{n}_0.png")) for n in ("jutsu", "training", "blank"))
    jutsu_tris, training_tris, blank_tris = load_obj("scroll_jutsu"), load_obj("scroll_training"), load_obj("scroll_blank")
    for release, (hue, sat, val) in RELEASE_COLORS.items():
        tex = recolor(jutsu, hue, sat, val)
        tex.save(os.path.join(MODEL_TEX, f"scroll_jutsu_{release}.png"))
        icon(jutsu_tris, tex).save(os.path.join(ICON_DIR, f"scroll_jutsu_{release}_icon.png"))
    for nature, (hue, sat, val) in TRAINING_COLORS.items():
        tex = recolor(training, hue, sat, val, src=(205, 335))
        tex.save(os.path.join(MODEL_TEX, f"scroll_training_{nature}.png"))
        icon(training_tris, tex).save(os.path.join(ICON_DIR, f"scroll_training_{nature}_icon.png"))
    icon(blank_tris, blank).save(os.path.join(ICON_DIR, "scroll_blank_icon.png"))
    print(f"{len(RELEASE_COLORS)} jutsu scroll colors, {len(TRAINING_COLORS)} training scroll colors and their icons written")


if __name__ == "__main__":
    main()
