package com.shinobiarts.quest;

/** What a quest asks for. Gather quests are checked against your inventory; the rest count as they happen. */
public enum QuestType {
    KILL_BANDITS("kill_bandits"),
    KILL_MOBS("kill_mobs"),
    KILL_PLAYERS("kill_players"),
    FISH("fish"),
    GATHER("gather");

    private final String id;

    QuestType(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public static QuestType byId(String id) {
        for (QuestType t : values()) {
            if (t.id.equals(id)) return t;
        }
        return KILL_MOBS;
    }
}
