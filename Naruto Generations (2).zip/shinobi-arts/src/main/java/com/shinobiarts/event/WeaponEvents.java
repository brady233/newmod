package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.item.NinjaWeaponItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

/**
 * Weapon effects that hook into damage: the Jashin ritual's healing (needs the final number, after armor),
 * Kabutowari breaking through armor and shields, and the Gunbai sending projectiles back.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class WeaponEvents {
    private WeaponEvents() {}

    @Nullable
    private static NinjaWeaponItem.Ability held(LivingEntity entity) {
        return entity.getMainHandItem().getItem() instanceof NinjaWeaponItem weapon ? weapon.ability() : null;
    }

    @SubscribeEvent
    public static void onDamage(LivingDamageEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player) || event.getSource().getDirectEntity() != player) return;
        if (!event.getSource().is(DamageTypes.PLAYER_ATTACK) || event.getAmount() <= 0 || event.getEntity() == player) return;
        if (held(player) == NinjaWeaponItem.Ability.LIFESTEAL && player.getHealth() < player.getMaxHealth()) {
            player.heal(event.getAmount() * Config.f(Config.HIDAN_LIFESTEAL));
            player.serverLevel().sendParticles(ParticleTypes.DAMAGE_INDICATOR, player.getX(), player.getY(1.0), player.getZ(),
                    4, 0.3, 0.2, 0.3, 0.05);
        }
    }

    /**
     * Kabutowari: armor stops less of the blow. The hit is raised (before armor) so that what gets through armor is what
     * armor would let through plus the pierced share of what it would have stopped.
     */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || event.getSource().getDirectEntity() != attacker) return;
        if (!event.getSource().is(DamageTypes.PLAYER_ATTACK) && !event.getSource().is(DamageTypes.MOB_ATTACK)) return;
        if (event.getSource().is(DamageTypeTags.BYPASSES_ARMOR) || held(attacker) != NinjaWeaponItem.Ability.ARMOR_BREAK) return;
        LivingEntity target = event.getEntity();
        float armor = target.getArmorValue(), toughness = (float) target.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
        float amount = event.getAmount(), pierce = Config.f(Config.KABUTOWARI_PIERCE);
        if (armor <= 0 || amount <= 0 || pierce <= 0) return;
        float through = CombatRules.getDamageAfterAbsorb(amount, armor, toughness);
        float want = through + pierce * (amount - through);
        float lo = amount, hi = amount * 5f;                      // armor never stops more than 80%
        for (int i = 0; i < 24; i++) {                            // what armor lets through only grows with the hit
            float mid = (lo + hi) / 2f;
            if (CombatRules.getDamageAfterAbsorb(mid, armor, toughness) < want) lo = mid; else hi = mid;
        }
        event.setAmount(hi);
    }

    /** Kabutowari knocks a raised shield (or a guarding Gunbai) out of its holder's hands for a while. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player victim) || victim.level().isClientSide || !victim.isBlocking()) return;
        if (!(event.getSource().getDirectEntity() instanceof LivingEntity attacker) || event.getSource().getEntity() != attacker) return;
        if (held(attacker) != NinjaWeaponItem.Ability.ARMOR_BREAK) return;
        int ticks = Config.i(Config.KABUTOWARI_SHIELD_TICKS);
        if (ticks <= 0) return;
        victim.getCooldowns().addCooldown(victim.getUseItem().getItem(), ticks);
        victim.stopUsingItem();
        victim.level().broadcastEntityEvent(victim, (byte) 30);   // the shield-breaking sound
    }

    /** A guarding Gunbai sends projectiles that hit it from the front back at whoever threw them. */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit) || !(hit.getEntity() instanceof Player guard)) return;
        if (guard.level().isClientSide || !guard.isBlocking()) return;
        if (!(guard.getUseItem().getItem() instanceof NinjaWeaponItem weapon) || weapon.ability() != NinjaWeaponItem.Ability.REFLECT) return;
        Projectile projectile = event.getProjectile();
        Vec3 look = guard.getViewVector(1.0f);
        Vec3 fromGuard = projectile.position().subtract(guard.position());
        if (new Vec3(fromGuard.x, 0, fromGuard.z).normalize().dot(new Vec3(look.x, 0, look.z).normalize()) <= 0) return; // behind
        Entity thrower = projectile.getOwner();
        double speed = Math.max(1.0, projectile.getDeltaMovement().length());
        Vec3 dir = thrower != null && thrower != guard && thrower.isAlive()
                ? thrower.getBoundingBox().getCenter().subtract(projectile.position()).normalize() : look;
        if (projectile instanceof JutsuProjectile jutsu) {
            jutsu.reflect(guard, dir.scale(speed));
        } else {
            projectile.setOwner(guard);
            projectile.setDeltaMovement(dir.scale(speed));
            if (projectile instanceof AbstractHurtingProjectile fireball) {
                fireball.xPower = dir.x * 0.1;
                fireball.yPower = dir.y * 0.1;
                fireball.zPower = dir.z * 0.1;
            }
            projectile.hasImpulse = true;
        }
        event.setCanceled(true);
        Vec3 at = projectile.position();
        guard.level().playSound(null, at.x, at.y, at.z, SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0f, 1.3f);
        if (guard.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CLOUD, at.x, at.y, at.z, 8, 0.2, 0.2, 0.2, 0.08);
        }
        guard.getUseItem().hurtAndBreak(1, guard, p -> p.broadcastBreakEvent(p.getUsedItemHand()));
    }
}
