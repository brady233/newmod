package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.effect.AmaterasuEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ShinobiArts.MODID);

    public static final RegistryObject<MobEffect> AMATERASU = EFFECTS.register("amaterasu", AmaterasuEffect::new);

    private ModEffects() {}
}
