package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * THE central store for everything the mod tracks about a player: identity (clan, natures),
 * progression (level, XP, stat points), resources (chakra, Senjutsu, Ryo), jutsu and cooldowns.
 *
 * <p>Only the server changes this, through {@link PlayerDataManager} (which also syncs the
 * client copy). Health and max health stay in vanilla's attributes, so they are not duplicated here.
 * The NBT carries a DataVersion so older saves are upgraded instead of reset.</p>
 */
public class NinjaData {
    public static final Capability<NinjaData> CAP = CapabilityManager.get(new CapabilityToken<>() {});

    /** Bump when the save format changes, and add a migration step in {@link #load}. */
    public static final int DATA_VERSION = 6;
    public static final float BASE_MAX_CHAKRA = 100f;

    // identity
    private boolean initialized;
    private Clan clan = Clan.NONE;
    // /clanroll: how many rolls this player has used, and whether they've locked their clan in
    private int clanRolls;
    private boolean clanClaimed;
    private String clanReleaseGiven = "";
    // every clan this player has rolled, in order: /clanroll claim <clan> keeps any one of them
    private final List<String> rolledClans = new ArrayList<>();
    // kekkei genkai awakened from DNA or a kekkei genkai scroll (KekkeiGenkai ids), and the release items already handed out
    private final java.util.LinkedHashSet<String> bloodlines = new java.util.LinkedHashSet<>();
    private final java.util.LinkedHashSet<String> releasesGiven = new java.util.LinkedHashSet<>();
    private ChakraNature affinity = ChakraNature.FIRE;
    private boolean affinityRevealed;
    private final Set<ChakraNature> natures = EnumSet.noneOf(ChakraNature.class);

    // jutsu
    private final List<String> learned = new ArrayList<>();
    private final Map<ChakraNature, Integer> selectedSlot = new EnumMap<>(ChakraNature.class);
    private final Map<String, Long> cooldowns = new HashMap<>();
    // Jutsu Points (a chance on each level-up) and how many times each jutsu has been upgraded
    private int jutsuPoints;
    private final Map<String, Integer> jutsuUpgrades = new HashMap<>();

    // progression
    private Rank rank = Rank.GENIN;
    private int level = 1;
    private long xp;
    private int earnedPoints;
    private final Map<Stat, Integer> stats = new EnumMap<>(Stat.class);

    // resources
    private float chakra = BASE_MAX_CHAKRA;
    private float senjutsu;
    private long ryo;

    // eyes: Sharingan stage 0 (none), 1-3 tomoe, 4 Mangekyou; owned by anyone who unlocked or implanted it
    private int sharinganStage;
    private Dojutsu activeDojutsu = Dojutsu.NONE;
    // the Mangekyou's pattern (decides the eye techniques on Jutsu 1/2/3), and the dojutsu equipment slot
    private MangekyouDesign mangekyouDesign = MangekyouDesign.ITACHI;
    // the Eternal Mangekyou is its own unlock on top of the pattern; and which eyes the V key switches on:
    // 0 = the tomoe Sharingan (up to 3 tomoe), 1 = the Mangekyou (double-tap V), 2 = the Eternal Mangekyou (triple-tap V)
    private boolean eternalUnlocked;
    private int sharinganMode;
    private net.minecraft.world.item.ItemStack dojutsuItem = net.minecraft.world.item.ItemStack.EMPTY;
    // not saved: crouching last tick (crouching with the Mangekyou on puts out Amaterasu) and the look last sent to others
    private boolean wasCrouching;
    private int lastLook = -1;
    // not saved: hanging from a ceiling with Chakra Control (set on both sides; others see it through the look bits)
    private boolean onCeiling;

    // XP boost token: multiplier and ticks left (counts down only while online)
    private float boostMultiplier = 1f;
    private int boostTicks;

    // village: the one in effect (from permissions, else the admin assignment) and the admin assignment itself
    private String village = "";
    private boolean kage;
    private String assignedVillage = "";
    private boolean assignedKage;
    // Village Advisor: in effect (from permissions or an appointment) and the village they were appointed in
    private boolean advisor;
    private String advisorOf = "";

    // combat tag (game time it ends) and who it's with
    private long combatUntil;
    private String combatWith = "";
    @Nullable
    private java.util.UUID combatWithId;

    // short-lived states (game-time stamps)
    private boolean charging;
    private boolean sageMode;
    private long rasenganUntil;
    private long substitutionUntil;
    private long rotationUntil;
    private long fallProtectUntil;
    private long intangibleUntil;      // Kamui: attacks pass through you until then (or until the key is let go)
    private boolean kamuiFlight;       // Kamui gave this player flight (taken away again when it ends)
    private long stunUntil;            // frozen (Tsukuyomi...): can't move, attack or use jutsu until then
    private int stunKind;              // what froze them (Afflictions.STUN_*), for the client's screen effect
    private long sealedUntil;          // chakra points sealed (64 Palms...): no jutsu or eye techniques until then
    private long allSeeingUntil;       // Byakugan's All-Seeing Eye
    private int gatesOpen;             // Eight Inner Gates: how many are open (0-8)
    private long gate8Until;           // when the Gate of Death closes by itself
    private long gatesLockedUntil;     // after the Gate of Death, the gates stay shut until then
    // Susanoo (see Susanoo.java): the stage (0 = none), its health, and the colours the player chose
    private int susanooStage;
    private float susanooHp, susanooMaxHp;
    private long susanooLastHit;       // regeneration waits a few seconds after a hit
    private long susanooBurnUntil;     // Amaterasu burning on it
    private boolean susanooGaveFlight; // the Perfect Susanoo turned flight on, so it turns it off again
    private int susanooCombo;          // which swing of the combo is next (0-2)
    private long susanooLastSwing;
    private int[] susanooColors = defaultSusanooColors();
    // toggles, kept through death: Substitution's auto-dodge and Chakra Control (tree climbing, water walking)
    private boolean substitutionOn;
    private boolean chakraControl;
    private long lightningArmorUntil;  // Lightning Armor's glow

    @Nullable
    public static NinjaData get(Player player) {
        return player.getCapability(CAP).orElse(null);
    }

    /** First-join setup: a hidden nature affinity and no clan yet (players roll one with /clanroll). */
    public void init(RandomSource random) {
        clan = Clan.NONE;
        clanRolls = 0;
        clanClaimed = false;
        clanReleaseGiven = "";
        rolledClans.clear();
        bloodlines.clear();
        releasesGiven.clear();
        affinity = ChakraNature.ELEMENTS[random.nextInt(ChakraNature.ELEMENTS.length)];
        affinityRevealed = false;
        natures.clear();
        learned.clear();
        selectedSlot.clear();
        cooldowns.clear();
        rank = Rank.GENIN;
        level = 1;
        xp = 0;
        earnedPoints = 0;
        stats.clear();
        senjutsu = 0;
        ryo = 0;
        sharinganStage = clan.buffs().sharinganAtBirth() ? 1 : 0; // Uchiha are born with a 1-tomoe Sharingan
        mangekyouDesign = MangekyouDesign.ITACHI;
        eternalUnlocked = false;
        sharinganMode = 0;
        boostMultiplier = 1f;
        boostTicks = 0;
        jutsuPoints = 0;
        jutsuUpgrades.clear();
        resetStates();
        chakra = maxChakra();
        initialized = true;
    }

    // ================================================================ progression

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = Math.max(1, level);
    }

    public long getXp() {
        return xp;
    }

    public void setXp(long xp) {
        this.xp = Math.max(0, xp);
    }

    /** XP needed to go from the current level to the next. */
    public long xpToNext() {
        return xpForLevel(level);
    }

    public static long xpForLevel(int level) {
        return Config.i(Config.XP_BASE) + (long) Math.max(0, level - 1) * Config.i(Config.XP_PER_LEVEL);
    }

    /** True when the player has reached their rank's level cap. */
    public boolean isMaxLevel() {
        return level >= rank.levelCap();
    }

    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }

    public int getEarnedPoints() {
        return earnedPoints;
    }

    public void setEarnedPoints(int points) {
        earnedPoints = Math.max(0, points);
    }

    public int stat(Stat stat) {
        return stats.getOrDefault(stat, 0);
    }

    public void setStat(Stat stat, int value) {
        stats.put(stat, Mth.clamp(value, 0, stat.cap()));
    }

    public int allocatedPoints() {
        int sum = 0;
        for (int v : stats.values()) sum += v;
        return sum;
    }

    public int availablePoints() {
        return Math.max(0, earnedPoints - allocatedPoints());
    }

    public void clearStats() {
        stats.clear();
    }

    /** Ryo cost of a stat reset at the current level. */
    public long resetCost() {
        return Config.i(Config.RESET_COST_BASE) + (long) Config.i(Config.RESET_COST_PER_LEVEL) * level;
    }

    /** Multiplier from the Genjutsu stat (1.0 at 0 points). */
    public float genjutsuMultiplier() {
        return 1f + stat(Stat.GENJUTSU) * Config.f(Config.GENJUTSU_PER_POINT) + clan.buffs().genjutsu();
    }

    // ================================================================ chakra & senjutsu

    public float maxChakra() {
        float base = BASE_MAX_CHAKRA * (1f + clan.buffs().chakra()); // e.g. Uzumaki +50%
        return base + stat(Stat.NINJUTSU) * Config.i(Config.CHAKRA_PER_NINJUTSU);
    }

    public float regenPerSecond() {
        float base = Config.f(Config.BASE_CHAKRA_REGEN) * (1f + clan.buffs().chakraRegen());
        base += stat(Stat.NINJUTSU) * Config.f(Config.NINJUTSU_REGEN_PER_POINT);
        return base * Config.f(Config.CHAKRA_REGEN_MULTIPLIER);
    }

    public float getChakra() {
        return chakra;
    }

    public void setChakra(float value) {
        chakra = Mth.clamp(value, 0f, maxChakra());
    }

    public void addChakra(float amount) {
        setChakra(chakra + amount);
    }

    public void consumeChakra(float amount) {
        setChakra(chakra - amount);
    }

    public float maxSenjutsu() {
        return stat(Stat.SENJUTSU) * Config.i(Config.SENJUTSU_PER_POINT);
    }

    public float getSenjutsu() {
        return senjutsu;
    }

    public void setSenjutsu(float value) {
        senjutsu = Mth.clamp(value, 0f, maxSenjutsu());
    }

    // ================================================================ ryo

    public long getRyo() {
        return ryo;
    }

    /** Only PlayerDataManager should call this; it validates every transaction. */
    void setRyo(long value) {
        ryo = Math.max(0, value);
    }

    // ================================================================ identity

    public boolean isInitialized() {
        return initialized;
    }

    public Clan getClan() {
        return clan;
    }

    public void setClan(Clan clan) {
        this.clan = clan;
        if (clan.buffs().sharinganAtBirth() && sharinganStage == 0) sharinganStage = 1;
        if (!availableDojutsu().contains(activeDojutsu)) activeDojutsu = Dojutsu.NONE;
        setChakra(chakra);
    }

    public int getClanRolls() {
        return clanRolls;
    }

    public void setClanRolls(int rolls) {
        clanRolls = Math.max(0, rolls);
    }

    public boolean isClanClaimed() {
        return clanClaimed;
    }

    public void setClanClaimed(boolean claimed) {
        clanClaimed = claimed;
    }

    /**
     * The clan is theirs for good: claimed with /clanroll claim, or no rolls left and only one clan to choose from
     * (with several rolled clans the player picks one with /clanroll claim).
     */
    public boolean isClanFinal() {
        return clan != Clan.NONE && (clanClaimed || (clanRolls >= com.shinobiarts.Config.i(com.shinobiarts.Config.CLAN_ROLLS)
                && rolledClanChoices().size() <= 1));
    }

    /** Every clan this player has rolled, oldest first, each once. */
    public List<Clan> rolledClanChoices() {
        List<Clan> out = new ArrayList<>();
        for (String id : rolledClans) {
            Clan c = Clan.byId(id);
            if (c != null && c != Clan.NONE && !out.contains(c)) out.add(c);
        }
        return out;
    }

    public void addRolledClan(Clan c) {
        if (c != null && c != Clan.NONE) rolledClans.add(c.id());
    }

    public void clearRolledClans() {
        rolledClans.clear();
    }

    /** Id of the clan release this player was last handed (with its first jutsu), "" if none yet. */
    public String getClanReleaseGiven() {
        return clanReleaseGiven;
    }

    public void setClanReleaseGiven(String id) {
        clanReleaseGiven = id == null ? "" : id;
    }

    /**
     * Switches to a newly rolled clan: born-with eyes come and go with the clan (rolling away from Uchiha takes
     * the Sharingan back), and a clan's fixed affinity applies unless the player already revealed theirs.
     */
    public void applyRolledClan(Clan newClan) {
        Clan old = clan;
        // (a Sharingan awakened from DNA stays: it isn't the clan's)
        if (old.buffs().sharinganAtBirth() && !newClan.buffs().sharinganAtBirth() && !bloodlines.contains("sharingan")) setSharinganStage(0);
        setClan(newClan);
        if (newClan.affinity() != null && !affinityRevealed) affinity = newClan.affinity();
    }

    public ChakraNature getAffinity() {
        return affinity;
    }

    public void setAffinity(ChakraNature affinity) {
        this.affinity = affinity;
    }

    public boolean isAffinityRevealed() {
        return affinityRevealed;
    }

    public void revealAffinity() {
        affinityRevealed = true;
        natures.add(affinity);
    }

    /**
     * True if the player may use jutsu of this release. Ninjutsu is open to everyone; a clan release (Wood...) to
     * members of its clan once the clan is theirs for good.
     */
    public boolean hasNature(ChakraNature nature) {
        if (nature == ChakraNature.NONE) return true;
        if (nature.isClanRelease()) return (clan == nature.clan() && isClanFinal()) || bloodlines.contains(nature.id());
        return natures.contains(nature);
    }

    // ================================================================ kekkei genkai from DNA / scrolls

    public boolean hasBloodline(String id) {
        return bloodlines.contains(id);
    }

    public void addBloodline(String id) {
        bloodlines.add(id);
    }

    public void removeBloodline(String id) {
        bloodlines.remove(id);
    }

    public Set<String> getBloodlines() {
        return java.util.Collections.unmodifiableSet(bloodlines);
    }

    /** Release items already handed out (one each, the first time a kekkei genkai release is usable). */
    public boolean wasReleaseGiven(ChakraNature release) {
        return releasesGiven.contains(release.id()) || release.id().equals(clanReleaseGiven);
    }

    public void markReleaseGiven(ChakraNature release) {
        releasesGiven.add(release.id());
    }

    /** True if the player has the Byakugan: born Hyuga or Otsutsuki, or awakened from DNA. */
    public boolean hasByakugan() {
        return clan.buffs().hasByakugan() || bloodlines.contains("byakugan");
    }

    public void unlockNature(ChakraNature nature) {
        if (nature.isElement()) natures.add(nature);
    }

    public Set<ChakraNature> getNatures() {
        return natures;
    }

    // ================================================================ jutsu & slots

    public boolean knows(String jutsuId) {
        return learned.contains(jutsuId);
    }

    public void learn(String jutsuId) {
        if (!learned.contains(jutsuId)) learned.add(jutsuId);
    }

    public void forget(String jutsuId) {
        learned.remove(jutsuId);
        for (ChakraNature r : ChakraNature.RELEASES) setSelectedSlot(r, getSelectedSlot(r));
    }

    /** Every learned jutsu, in the order learned. */
    public List<Jutsu> learnedJutsu() {
        List<Jutsu> out = new ArrayList<>();
        for (String id : learned) {
            Jutsu j = Jutsus.get(id);
            if (j != null) out.add(j);
        }
        return out;
    }

    /** The jutsu slots of one release: its learned jutsu in the order learned. */
    public List<Jutsu> slots(ChakraNature release) {
        List<Jutsu> out = new ArrayList<>();
        for (Jutsu j : learnedJutsu()) {
            // Substitution isn't cast from a release: it's switched on with its own key
            if (j.release() == release && j != com.shinobiarts.jutsu.Jutsus.SUBSTITUTION) out.add(j);
        }
        return out;
    }

    public int getSelectedSlot(ChakraNature release) {
        int size = slots(release).size();
        if (size == 0) return 0;
        return Mth.clamp(selectedSlot.getOrDefault(release, 0), 0, size - 1);
    }

    public void setSelectedSlot(ChakraNature release, int index) {
        int size = slots(release).size();
        selectedSlot.put(release, size == 0 ? 0 : Mth.clamp(index, 0, size - 1));
    }

    /** Moves the selection arrow, wrapping around. */
    public void moveSlot(ChakraNature release, int direction) {
        int size = slots(release).size();
        if (size == 0) return;
        selectedSlot.put(release, Math.floorMod(getSelectedSlot(release) + direction, size));
    }

    @Nullable
    public Jutsu selectedJutsu(ChakraNature release) {
        List<Jutsu> list = slots(release);
        return list.isEmpty() ? null : list.get(getSelectedSlot(release));
    }

    public long cooldownRemaining(String jutsuId, long now) {
        Long ready = cooldowns.get(jutsuId);
        return ready == null ? 0 : Math.max(0, ready - now);
    }

    public void setCooldown(String jutsuId, long readyAt) {
        cooldowns.put(jutsuId, readyAt);
    }

    public void clearCooldowns() {
        cooldowns.clear();
    }

    // ================================================================ short-lived states

    public boolean isDojutsuActive() {
        return activeDojutsu != Dojutsu.NONE;
    }

    public Dojutsu getActiveDojutsu() {
        return activeDojutsu;
    }

    public void setActiveDojutsu(Dojutsu dojutsu) {
        activeDojutsu = dojutsu == null ? Dojutsu.NONE : dojutsu;
    }

    /** True while the Sharingan (any stage) is switched on. */
    public boolean isSharinganActive() {
        return activeDojutsu == Dojutsu.SHARINGAN && sharinganStage > 0;
    }

    /**
     * The stage the Sharingan shows when switched on: the highest tomoe stage owned (up to 3) normally, the Mangekyou
     * when it was switched on with a double (or triple) tap of V.
     */
    public int activeSharinganStage() {
        if (sharinganStage >= Dojutsu.MANGEKYOU && sharinganMode >= 1) return Dojutsu.MANGEKYOU;
        return Math.min(sharinganStage, 3);
    }

    /** 0 = tomoe, 1 = Mangekyou, 2 = Eternal Mangekyou: which eyes the V key last switched on. */
    public int getSharinganMode() {
        return sharinganMode;
    }

    public void setSharinganMode(int mode) {
        int max = sharinganStage >= Dojutsu.MANGEKYOU ? (eternalUnlocked ? 2 : 1) : 0;
        sharinganMode = Mth.clamp(mode, 0, max);
    }

    public boolean hasEternal() {
        return eternalUnlocked;
    }

    /** The eye techniques this player owns, in the order V cycles through them. */
    public List<Dojutsu> availableDojutsu() {
        List<Dojutsu> out = new ArrayList<>();
        if (sharinganStage > 0) out.add(Dojutsu.SHARINGAN);
        if (hasByakugan()) out.add(Dojutsu.BYAKUGAN);
        return out;
    }

    /** Display name of an eye technique (the Sharingan includes its stage). */
    public net.minecraft.network.chat.MutableComponent dojutsuName(Dojutsu dojutsu) {
        return dojutsu == Dojutsu.BYAKUGAN ? Dojutsu.byakuganName() : Dojutsu.sharinganName(activeSharinganStage(), getMangekyouDesign());
    }

    /** The strongest Sharingan this player has unlocked (the Eternal Mangekyou counts as the best). */
    public net.minecraft.network.chat.MutableComponent unlockedSharinganName() {
        return Dojutsu.sharinganName(sharinganStage, eternalUnlocked ? MangekyouDesign.ETERNAL : mangekyouDesign);
    }

    public int getSharinganStage() {
        return sharinganStage;
    }

    /** Only SharinganManager should change this (it enforces the evolution order). */
    public void setSharinganStage(int stage) {
        sharinganStage = Mth.clamp(stage, 0, Dojutsu.MANGEKYOU);
        if (sharinganStage == 0 && activeDojutsu == Dojutsu.SHARINGAN) activeDojutsu = Dojutsu.NONE;
        if (sharinganStage < Dojutsu.MANGEKYOU) {
            sharinganMode = 0;
            eternalUnlocked = false;
        }
    }

    /**
     * The Mangekyou pattern in use: the Eternal Mangekyou while it's switched on (triple-tap V), otherwise the pattern
     * the eyes awakened with (Itachi, Sasuke or Obito). It decides the eye techniques on Jutsu 1/2/3.
     */
    public MangekyouDesign getMangekyouDesign() {
        return sharinganMode >= 2 && eternalUnlocked ? MangekyouDesign.ETERNAL : mangekyouDesign;
    }

    /** The pattern the Mangekyou awakened with (never Eternal). */
    public MangekyouDesign getBaseMangekyouDesign() {
        return mangekyouDesign;
    }

    /** Sets the pattern; the Eternal Mangekyou unlocks the Eternal eyes on top of the current pattern instead. */
    public void setMangekyouDesign(MangekyouDesign design) {
        if (design == MangekyouDesign.ETERNAL) {
            eternalUnlocked = true;
            return;
        }
        mangekyouDesign = design == null ? MangekyouDesign.ITACHI : design;
    }

    public void setEternalUnlocked(boolean b) {
        eternalUnlocked = b;
        if (!b && sharinganMode > 1) sharinganMode = 1;
    }

    /** True while the Mangekyou (any pattern) is switched on. */
    public boolean isMangekyouActive() {
        return isSharinganActive() && activeSharinganStage() == Dojutsu.MANGEKYOU;
    }

    /** The item in the dojutsu equipment slot (the Sharingan), or EMPTY. */
    public net.minecraft.world.item.ItemStack getDojutsuItem() {
        return dojutsuItem;
    }

    public void setDojutsuItem(net.minecraft.world.item.ItemStack stack) {
        dojutsuItem = stack == null ? net.minecraft.world.item.ItemStack.EMPTY : stack;
    }

    public boolean isOnCeiling() {
        return onCeiling;
    }

    public void setOnCeiling(boolean b) {
        onCeiling = b;
    }

    public boolean wasCrouching() {
        return wasCrouching;
    }

    public void setWasCrouching(boolean crouching) {
        wasCrouching = crouching;
    }

    /** What other players were last told about this player's eyes (see SharinganManager.look), -1 = nothing yet. */
    public int getLastLook() {
        return lastLook;
    }

    public void setLastLook(int look) {
        lastLook = look;
    }

    // ---------------------------------------------------------------- jutsu upgrades

    public int getJutsuPoints() {
        return jutsuPoints;
    }

    public void setJutsuPoints(int points) {
        jutsuPoints = Math.max(0, points);
    }

    /** How many times a jutsu has been upgraded (0 = never). */
    public int jutsuUpgrade(String jutsuId) {
        return jutsuUpgrades.getOrDefault(jutsuId, 0);
    }

    public void setJutsuUpgrade(String jutsuId, int upgrades) {
        if (upgrades <= 0) jutsuUpgrades.remove(jutsuId);
        else jutsuUpgrades.put(jutsuId, upgrades);
    }

    /** Everything that scales a jutsu's damage for this player: its upgrades and the clan's jutsu bonuses. */
    public float jutsuBonus(Jutsu jutsu) {
        float upgrades = Jutsus.upgradeable(jutsu) ? jutsuDamageMultiplier(jutsu.id()) : 1f;
        return upgrades * clan.buffs().jutsuMultiplier(jutsu.release());
    }

    /** Damage multiplier from upgrades, e.g. 1.3 after two upgrades at +15% each. */
    public float jutsuDamageMultiplier(String jutsuId) {
        return 1f + jutsuUpgrade(jutsuId) * com.shinobiarts.Config.f(com.shinobiarts.Config.JUTSU_UPGRADE_DAMAGE);
    }

    // ---------------------------------------------------------------- XP boost

    public float getBoostMultiplier() {
        return boostTicks > 0 ? boostMultiplier : 1f;
    }

    public int getBoostTicks() {
        return boostTicks;
    }

    public void setBoost(float multiplier, int ticks) {
        boostMultiplier = Math.max(1f, multiplier);
        boostTicks = Math.max(0, ticks);
    }

    // ---------------------------------------------------------------- village

    /** Village id the player belongs to ("" = none). Set by VillageManager. */
    public String getVillage() {
        return village;
    }

    public boolean isKage() {
        return kage && !village.isEmpty();
    }

    public void setVillage(String village, boolean kage) {
        this.village = village == null ? "" : village;
        this.kage = kage;
    }

    public String getAssignedVillage() {
        return assignedVillage;
    }

    public boolean isAssignedKage() {
        return assignedKage;
    }

    /** A Village Advisor: someone players can go to for help. Set by VillageManager. */
    public boolean isAdvisor() {
        return advisor && !village.isEmpty();
    }

    public void setAdvisor(boolean advisor) {
        this.advisor = advisor;
    }

    /** The village a Kage or admin appointed this player Advisor of ("" = not appointed). */
    public String getAdvisorOf() {
        return advisorOf;
    }

    public void setAdvisorOf(String village) {
        this.advisorOf = village == null ? "" : village;
    }

    /** Admin assignment (/shinobi village, /shinobi kage), used when permissions don't place the player. */
    public void setAssignment(String village, boolean kage) {
        this.assignedVillage = village == null ? "" : village;
        this.assignedKage = kage;
    }

    // ---------------------------------------------------------------- combat tag

    public long getCombatUntil() {
        return combatUntil;
    }

    public boolean isInCombat(long now) {
        return combatUntil > now;
    }

    public String getCombatWith() {
        return combatWith;
    }

    @Nullable
    public java.util.UUID getCombatWithId() {
        return combatWithId;
    }

    public void setCombat(long until, String with, @Nullable java.util.UUID withId) {
        combatUntil = until;
        combatWith = with == null ? "" : with;
        combatWithId = withId;
    }

    public void clearCombat() {
        setCombat(0, "", null);
    }

    public boolean isCharging() {
        return charging;
    }

    public void setCharging(boolean charging) {
        this.charging = charging;
    }

    public boolean isSageMode() {
        return sageMode;
    }

    public void setSageMode(boolean sageMode) {
        this.sageMode = sageMode;
    }

    /** The Rasengan takes this long to form (two shadow clones shape it), then stays in hand for RASENGAN_HOLD_TICKS. */
    public static final int RASENGAN_FORM_TICKS = 30;
    public static final int RASENGAN_HOLD_TICKS = 200;

    public long getRasenganUntil() {
        return rasenganUntil;
    }

    /** Still being formed: it can't hit anything yet. */
    public boolean isRasenganForming(long now) {
        return rasenganUntil > now && rasenganUntil - now > RASENGAN_HOLD_TICKS;
    }

    /** Formed and in hand: the next punch sets it off. */
    public boolean hasRasengan(long now) {
        return rasenganUntil > now && !isRasenganForming(now);
    }

    public void setRasenganUntil(long t) {
        rasenganUntil = t;
    }

    public long getSubstitutionUntil() {
        return substitutionUntil;
    }

    public void setSubstitutionUntil(long t) {
        substitutionUntil = t;
    }

    public long getRotationUntil() {
        return rotationUntil;
    }

    public void setRotationUntil(long t) {
        rotationUntil = t;
    }

    public long getIntangibleUntil() {
        return intangibleUntil;
    }

    public void setIntangibleUntil(long t) {
        intangibleUntil = t;
    }

    public boolean isIntangible(long now) {
        return intangibleUntil > now;
    }

    public long getStunUntil() {
        return stunUntil;
    }

    public int getStunKind() {
        return stunKind;
    }

    public void setStun(long until, int kind) {
        stunUntil = until;
        stunKind = kind;
    }

    public boolean isStunned(long now) {
        return stunUntil > now;
    }

    public long getSealedUntil() {
        return sealedUntil;
    }

    public void setSealedUntil(long t) {
        sealedUntil = t;
    }

    public boolean isSealed(long now) {
        return sealedUntil > now;
    }

    public int getGatesOpen() {
        return gatesOpen;
    }

    public void setGatesOpen(int g) {
        gatesOpen = Math.max(0, Math.min(8, g));
    }

    public long getGate8Until() {
        return gate8Until;
    }

    public void setGate8Until(long t) {
        gate8Until = t;
    }

    public long getGatesLockedUntil() {
        return gatesLockedUntil;
    }

    public void setGatesLockedUntil(long t) {
        gatesLockedUntil = t;
    }

    public long getAllSeeingUntil() {
        return allSeeingUntil;
    }

    public void setAllSeeingUntil(long t) {
        allSeeingUntil = t;
    }

    public boolean kamuiGaveFlight() {
        return kamuiFlight;
    }

    public void setKamuiGaveFlight(boolean b) {
        kamuiFlight = b;
    }

    /** Substitution's auto-dodge is switched on (the Substitution key). */
    public boolean isSubstitutionOn() {
        return substitutionOn;
    }

    public void setSubstitutionOn(boolean b) {
        substitutionOn = b;
    }

    /** Chakra Control is switched on: climb by looking up against a wall, walk on water. */
    public boolean isChakraControl() {
        return chakraControl;
    }

    public void setChakraControl(boolean b) {
        chakraControl = b;
    }

    public long getLightningArmorUntil() {
        return lightningArmorUntil;
    }

    public void setLightningArmorUntil(long t) {
        lightningArmorUntil = t;
    }

    public long getFallProtectUntil() {
        return fallProtectUntil;
    }

    public void setFallProtectUntil(long t) {
        fallProtectUntil = t;
    }

    /** Clears toggles and buffs, e.g. on death. */
    public void resetStates() {
        activeDojutsu = Dojutsu.NONE;
        clearCombat();
        charging = false;
        sageMode = false;
        rasenganUntil = substitutionUntil = rotationUntil = 0;
        fallProtectUntil = 0;
        intangibleUntil = lightningArmorUntil = 0;
        stunUntil = sealedUntil = allSeeingUntil = 0;
        stunKind = 0;
        gatesOpen = 0;
        gate8Until = 0;
        susanooStage = 0;
        susanooBurnUntil = 0;
        susanooCombo = 0;
    }

    // ================================================================ Susanoo

    /** Colour slots: body, armor, weapon, eyes, chakra (rim light and glow), aura. */
    public static final String[] SUSANOO_PARTS = {"body", "armor", "weapon", "eyes", "chakra", "aura"};

    public static int[] defaultSusanooColors() {
        return new int[]{0x8A55FF, 0x6B3BE6, 0xD8C2FF, 0xFFFFFF, 0x8A55FF, 0x8A55FF};
    }

    public int getSusanooStage() {
        return susanooStage;
    }

    public void setSusanooStage(int stage) {
        susanooStage = Mth.clamp(stage, 0, 5);
    }

    public float getSusanooHp() {
        return susanooHp;
    }

    public void setSusanooHp(float hp) {
        susanooHp = Math.max(0, hp);
    }

    public float getSusanooMaxHp() {
        return susanooMaxHp;
    }

    public void setSusanooMaxHp(float hp) {
        susanooMaxHp = Math.max(1, hp);
    }

    public long getSusanooLastHit() {
        return susanooLastHit;
    }

    public void setSusanooLastHit(long t) {
        susanooLastHit = t;
    }

    public long getSusanooBurnUntil() {
        return susanooBurnUntil;
    }

    public void setSusanooBurnUntil(long t) {
        susanooBurnUntil = t;
    }

    public boolean susanooGaveFlight() {
        return susanooGaveFlight;
    }

    public void setSusanooGaveFlight(boolean b) {
        susanooGaveFlight = b;
    }

    public int getSusanooCombo() {
        return susanooCombo;
    }

    public void setSusanooCombo(int c) {
        susanooCombo = c;
    }

    public long getSusanooLastSwing() {
        return susanooLastSwing;
    }

    public void setSusanooLastSwing(long t) {
        susanooLastSwing = t;
    }

    public int[] getSusanooColors() {
        return susanooColors.clone();
    }

    public void setSusanooColor(int part, int rgb) {
        if (part >= 0 && part < susanooColors.length) susanooColors[part] = rgb & 0xFFFFFF;
    }

    public void setSusanooColors(int[] colors) {
        int[] d = defaultSusanooColors();
        for (int i = 0; i < d.length; i++) d[i] = colors != null && i < colors.length ? colors[i] & 0xFFFFFF : d[i];
        susanooColors = d;
    }

    // ================================================================ NBT

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("DataVersion", DATA_VERSION);
        tag.putBoolean("Initialized", initialized);
        tag.putString("Clan", clan.id());
        tag.putInt("ClanRolls", clanRolls);
        tag.putBoolean("ClanClaimed", clanClaimed);
        tag.putString("ClanReleaseGiven", clanReleaseGiven);
        ListTag rolled = new ListTag();
        for (String id : rolledClans) rolled.add(StringTag.valueOf(id));
        tag.put("RolledClans", rolled);
        ListTag blood = new ListTag();
        for (String id : bloodlines) blood.add(StringTag.valueOf(id));
        tag.put("Bloodlines", blood);
        ListTag given = new ListTag();
        for (String id : releasesGiven) given.add(StringTag.valueOf(id));
        tag.put("ReleasesGiven", given);
        tag.putString("Affinity", affinity.id());
        tag.putBoolean("AffinityRevealed", affinityRevealed);
        ListTag natureList = new ListTag();
        for (ChakraNature n : natures) natureList.add(StringTag.valueOf(n.id()));
        tag.put("Natures", natureList);

        ListTag learnedList = new ListTag();
        for (String id : learned) learnedList.add(StringTag.valueOf(id));
        tag.put("Learned", learnedList);
        CompoundTag slots = new CompoundTag();
        selectedSlot.forEach((r, i) -> slots.putInt(r.id(), i));
        tag.put("SelectedSlots", slots);
        CompoundTag cds = new CompoundTag();
        cooldowns.forEach(cds::putLong);
        tag.put("Cooldowns", cds);
        tag.putInt("JutsuPoints", jutsuPoints);
        CompoundTag upgrades = new CompoundTag();
        jutsuUpgrades.forEach(upgrades::putInt);
        tag.put("JutsuUpgrades", upgrades);

        tag.putString("Rank", rank.id());
        tag.putInt("Level", level);
        tag.putLong("Xp", xp);
        tag.putInt("EarnedPoints", earnedPoints);
        CompoundTag statTag = new CompoundTag();
        stats.forEach((s, v) -> statTag.putInt(s.id(), v));
        tag.put("Stats", statTag);

        tag.putFloat("Chakra", chakra);
        tag.putFloat("Senjutsu", senjutsu);
        tag.putLong("Ryo", ryo);

        tag.putString("Dojutsu", activeDojutsu.id());
        tag.putInt("SharinganStage", sharinganStage);
        tag.putString("MangekyouDesign", mangekyouDesign.id());
        tag.putBoolean("Eternal", eternalUnlocked);
        tag.putInt("SharinganMode", sharinganMode);
        if (!dojutsuItem.isEmpty()) tag.put("DojutsuItem", dojutsuItem.save(new CompoundTag()));
        tag.putFloat("BoostMultiplier", boostMultiplier);
        tag.putInt("BoostTicks", boostTicks);
        tag.putString("Village", village);
        tag.putBoolean("Kage", kage);
        tag.putString("AssignedVillage", assignedVillage);
        tag.putBoolean("AssignedKage", assignedKage);
        tag.putBoolean("Advisor", advisor);
        tag.putString("AdvisorOf", advisorOf);
        tag.putLong("CombatUntil", combatUntil);
        tag.putString("CombatWith", combatWith);
        if (combatWithId != null) tag.putUUID("CombatWithId", combatWithId);
        tag.putBoolean("Charging", charging);
        tag.putBoolean("SageMode", sageMode);
        tag.putLong("Rasengan", rasenganUntil);
        tag.putLong("Substitution", substitutionUntil);
        tag.putLong("Rotation", rotationUntil);
        tag.putLong("FallProtect", fallProtectUntil);
        tag.putLong("Intangible", intangibleUntil);
        tag.putBoolean("KamuiFlight", kamuiFlight);
        tag.putLong("Stun", stunUntil);
        tag.putInt("StunKind", stunKind);
        tag.putLong("Sealed", sealedUntil);
        tag.putLong("AllSeeing", allSeeingUntil);
        tag.putInt("Gates", gatesOpen);
        tag.putLong("Gate8", gate8Until);
        tag.putLong("GatesLocked", gatesLockedUntil);
        tag.putInt("SusanooStage", susanooStage);
        tag.putFloat("SusanooHp", susanooHp);
        tag.putFloat("SusanooMaxHp", susanooMaxHp);
        tag.putLong("SusanooBurn", susanooBurnUntil);
        tag.putBoolean("SusanooFlight", susanooGaveFlight);
        tag.putIntArray("SusanooColors", susanooColors);
        tag.putBoolean("SubstitutionOn", substitutionOn);
        tag.putBoolean("ChakraControl", chakraControl);
        tag.putLong("LightningArmor", lightningArmorUntil);
        return tag;
    }

    public void load(CompoundTag tag) {
        int version = tag.contains("DataVersion") ? tag.getInt("DataVersion") : 1;

        initialized = tag.getBoolean("Initialized");
        Clan c = Clan.byId(tag.getString("Clan"));
        clan = c == null ? Clan.NONE : c;
        clanRolls = Math.max(0, tag.getInt("ClanRolls"));
        // players from before /clanroll keep the clan they were born into
        clanClaimed = version < 4 ? clan != Clan.NONE : tag.getBoolean("ClanClaimed");
        ChakraNature a = ChakraNature.byId(tag.getString("Affinity"));
        affinity = a == null || !a.isElement() ? ChakraNature.FIRE : a;
        affinityRevealed = tag.getBoolean("AffinityRevealed");
        natures.clear();
        for (Tag t : tag.getList("Natures", Tag.TAG_STRING)) {
            ChakraNature n = ChakraNature.byId(t.getAsString());
            if (n != null && n.isElement()) natures.add(n);
        }
        bloodlines.clear();
        for (Tag t : tag.getList("Bloodlines", Tag.TAG_STRING)) bloodlines.add(t.getAsString());

        learned.clear();
        for (Tag t : tag.getList("Learned", Tag.TAG_STRING)) {
            String id = t.getAsString();
            if (!learned.contains(id)) learned.add(id);
        }
        selectedSlot.clear();
        CompoundTag slots = tag.getCompound("SelectedSlots");
        for (String key : slots.getAllKeys()) {
            ChakraNature r = ChakraNature.byId(key);
            if (r != null) selectedSlot.put(r, slots.getInt(key));
        }
        cooldowns.clear();
        CompoundTag cds = tag.getCompound("Cooldowns");
        for (String key : cds.getAllKeys()) cooldowns.put(key, cds.getLong(key));
        jutsuPoints = Math.max(0, tag.getInt("JutsuPoints"));
        jutsuUpgrades.clear();
        CompoundTag upgrades = tag.getCompound("JutsuUpgrades");
        for (String key : upgrades.getAllKeys()) {
            if (upgrades.getInt(key) > 0) jutsuUpgrades.put(key, upgrades.getInt(key));
        }
        if (version < 5) {
            // Amaterasu moved from a jutsu scroll to the Mangekyou's Jutsu 1 key: forget it and refund its upgrades.
            learned.remove("amaterasu");
            Integer spent = jutsuUpgrades.remove("amaterasu");
            if (spent != null) jutsuPoints += spent * Config.i(Config.JUTSU_UPGRADE_COST);
            cooldowns.remove("amaterasu");
        }

        stats.clear();
        Rank r = Rank.byId(tag.getString("Rank"));
        rank = r == null ? Rank.GENIN : r;
        if (version >= 2) {
            level = Math.max(1, tag.getInt("Level"));
            xp = Math.max(0, tag.getLong("Xp"));
            earnedPoints = Math.max(0, tag.getInt("EarnedPoints"));
            CompoundTag statTag = tag.getCompound("Stats");
            for (String key : statTag.getAllKeys()) {
                Stat s = Stat.byId(key);
                if (s != null) stats.put(s, Math.max(0, statTag.getInt(key)));
            }
            ryo = Math.max(0, tag.getLong("Ryo"));
        } else {
            // Version 1 grew max chakra by casting ("Trained"). Convert that into stat points:
            // 5 trained chakra = 1 point, the same value as a Ninjutsu point.
            level = 1;
            xp = 0;
            earnedPoints = Math.round(Math.max(0f, tag.getFloat("Trained")) / 5f);
            ryo = 0;
        }

        senjutsu = Mth.clamp(tag.getFloat("Senjutsu"), 0f, maxSenjutsu());
        chakra = Mth.clamp(tag.getFloat("Chakra"), 0f, maxChakra());

        sharinganStage = Mth.clamp(tag.getInt("SharinganStage"), 0, Dojutsu.MANGEKYOU);
        mangekyouDesign = MangekyouDesign.byId(tag.getString("MangekyouDesign")); // older saves: Itachi (Amaterasu, as before)
        eternalUnlocked = tag.getBoolean("Eternal");
        sharinganMode = tag.getInt("SharinganMode");
        if (version < 6) {
            // the Eternal Mangekyou used to replace the pattern; now it's unlocked on top of it (triple-tap V)
            if (mangekyouDesign == MangekyouDesign.ETERNAL) {
                eternalUnlocked = true;
                mangekyouDesign = MangekyouDesign.ITACHI;
            }
            // whoever had the Mangekyou keeps seeing it when the eyes come on
            sharinganMode = sharinganStage >= Dojutsu.MANGEKYOU ? (eternalUnlocked ? 2 : 1) : 0;
        }
        if (mangekyouDesign == MangekyouDesign.ETERNAL) mangekyouDesign = MangekyouDesign.ITACHI;
        if (sharinganStage < Dojutsu.MANGEKYOU) {
            sharinganMode = 0;
            eternalUnlocked = false;
        }
        sharinganMode = Mth.clamp(sharinganMode, 0, eternalUnlocked ? 2 : 1);
        dojutsuItem = tag.contains("DojutsuItem", Tag.TAG_COMPOUND)
                ? net.minecraft.world.item.ItemStack.of(tag.getCompound("DojutsuItem")) : net.minecraft.world.item.ItemStack.EMPTY;
        if (version < 3 && clan == Clan.UCHIHA && sharinganStage == 0) sharinganStage = 1; // v2 Uchiha get their 1-tomoe eyes
        if (tag.contains("Dojutsu", Tag.TAG_STRING)) {
            activeDojutsu = Dojutsu.byId(tag.getString("Dojutsu"));
        } else {
            List<Dojutsu> owned = availableDojutsu(); // v2 stored an on/off flag
            activeDojutsu = tag.getBoolean("Dojutsu") && !owned.isEmpty() ? owned.get(0) : Dojutsu.NONE;
        }
        if (!availableDojutsu().contains(activeDojutsu)) activeDojutsu = Dojutsu.NONE;
        boostMultiplier = tag.contains("BoostMultiplier") ? Math.max(1f, tag.getFloat("BoostMultiplier")) : 1f;
        boostTicks = Math.max(0, tag.getInt("BoostTicks"));
        village = tag.getString("Village");
        kage = tag.getBoolean("Kage");
        assignedVillage = tag.getString("AssignedVillage");
        assignedKage = tag.getBoolean("AssignedKage");
        advisor = tag.getBoolean("Advisor");
        advisorOf = tag.getString("AdvisorOf");
        combatUntil = tag.getLong("CombatUntil");
        combatWith = tag.getString("CombatWith");
        combatWithId = tag.hasUUID("CombatWithId") ? tag.getUUID("CombatWithId") : null;
        charging = tag.getBoolean("Charging");
        sageMode = tag.getBoolean("SageMode");
        rasenganUntil = tag.getLong("Rasengan");
        substitutionUntil = tag.getLong("Substitution");
        rotationUntil = tag.getLong("Rotation");
        fallProtectUntil = tag.getLong("FallProtect");
        intangibleUntil = tag.getLong("Intangible");
        kamuiFlight = tag.getBoolean("KamuiFlight");
        stunUntil = tag.getLong("Stun");
        stunKind = tag.getInt("StunKind");
        sealedUntil = tag.getLong("Sealed");
        allSeeingUntil = tag.getLong("AllSeeing");
        gatesOpen = tag.getInt("Gates");
        gate8Until = tag.getLong("Gate8");
        gatesLockedUntil = tag.getLong("GatesLocked");
        susanooStage = tag.getInt("SusanooStage");
        susanooHp = tag.getFloat("SusanooHp");
        susanooMaxHp = tag.getFloat("SusanooMaxHp");
        susanooBurnUntil = tag.getLong("SusanooBurn");
        susanooGaveFlight = tag.getBoolean("SusanooFlight");
        setSusanooColors(tag.contains("SusanooColors") ? tag.getIntArray("SusanooColors") : null);
        clanReleaseGiven = tag.getString("ClanReleaseGiven");
        rolledClans.clear();
        for (Tag t : tag.getList("RolledClans", Tag.TAG_STRING)) rolledClans.add(t.getAsString());
        releasesGiven.clear();
        for (Tag t : tag.getList("ReleasesGiven", Tag.TAG_STRING)) releasesGiven.add(t.getAsString());
        if (!clanReleaseGiven.isEmpty()) releasesGiven.add(clanReleaseGiven);
        substitutionOn = tag.getBoolean("SubstitutionOn");
        chakraControl = tag.getBoolean("ChakraControl");
        lightningArmorUntil = tag.getLong("LightningArmor");
    }
}
