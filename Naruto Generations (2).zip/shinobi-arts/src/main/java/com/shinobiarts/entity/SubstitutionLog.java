package com.shinobiarts.entity;

import com.shinobiarts.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * One of the two logs Substitution leaves where you stood. Purely for show: it can't be picked up, mined or
 * pushed, falls to the ground, and vanishes in a puff of smoke after {@code substitutionLogSeconds}. Never saved.
 */
public class SubstitutionLog extends Entity {
    private static final EntityDataAccessor<Boolean> UPRIGHT = SynchedEntityData.defineId(SubstitutionLog.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(SubstitutionLog.class, EntityDataSerializers.INT);

    public SubstitutionLog(EntityType<? extends SubstitutionLog> type, Level level) {
        super(type, level);
    }

    public static void spawn(ServerLevel level, Vec3 pos, float yaw, boolean upright, int lifeTicks, Vec3 motion) {
        SubstitutionLog log = new SubstitutionLog(ModEntities.SUBSTITUTION_LOG.get(), level);
        log.setPos(pos.x, pos.y, pos.z);
        log.setYRot(yaw);
        log.yRotO = yaw;
        log.entityData.set(UPRIGHT, upright);
        log.entityData.set(LIFE, Math.max(1, lifeTicks));
        log.setDeltaMovement(motion);
        level.addFreshEntity(log);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(UPRIGHT, true);
        this.entityData.define(LIFE, 200);
    }

    public boolean isUpright() {
        return this.entityData.get(UPRIGHT);
    }

    public int getLife() {
        return this.entityData.get(LIFE);
    }

    @Override
    public void tick() {
        super.tick();
        Vec3 motion = getDeltaMovement();
        if (!isNoGravity()) motion = motion.add(0, -0.04, 0);
        setDeltaMovement(motion);
        move(MoverType.SELF, getDeltaMovement());
        setDeltaMovement(getDeltaMovement().scale(0.98));
        if (onGround()) setDeltaMovement(getDeltaMovement().multiply(0.6, -0.3, 0.6));
        if (!level().isClientSide && tickCount >= getLife()) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.POOF, getX(), getY() + 0.4, getZ(), 12, 0.3, 0.3, 0.3, 0.02);
            discard();
        }
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
