package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * A chakra projectile (fireball, water bullet, water dragon...). The Great Fireball and the Water Bullet are drawn
 * as glowing sprites (client/JutsuProjectileRenderer); everything leaves a particle trail. The Great Fireball's
 * size (and blast radius) follows how long it was charged: {@link #getScale}.
 */
public class JutsuProjectile extends ThrowableProjectile {
    public enum Kind { FIRE_BALL, FIRE_SMALL, WATER_BULLET, WATER_DRAGON, RASENGAN, RASENSHURIKEN, ICE_NEEDLE, BONE_BULLET, MAGATAMA }

    private static final EntityDataAccessor<Byte> KIND = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.FLOAT);
    /** Chakra colour of a Susanoo's magatama (its owner's chosen colour). */
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.INT);
    /** Water Dragon: the point it flies to after rising out of the ground (both sides steer the same way). */
    private static final EntityDataAccessor<Vector3f> AIM = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.VECTOR3);
    /** Water Dragon: ticks spent rising straight up out of the ground before it turns toward its aim. */
    public static final int DRAGON_RISE = 7;
    public static final float DRAGON_SPEED = 1.15f;
    private static final DustParticleOptions WATER_DUST = new DustParticleOptions(new Vector3f(0.2f, 0.5f, 1.0f), 1.4f);
    private static final DustParticleOptions WATER_DUST_BIG = new DustParticleOptions(new Vector3f(0.15f, 0.4f, 0.95f), 2.4f);
    private static final DustParticleOptions CHAKRA_DUST = new DustParticleOptions(new Vector3f(0.45f, 0.8f, 1.0f), 1.3f);
    private static final DustParticleOptions WIND_DUST = new DustParticleOptions(new Vector3f(0.85f, 0.95f, 1.0f), 1.6f);
    private static final DustParticleOptions ICE_DUST = new DustParticleOptions(new Vector3f(0.75f, 0.92f, 1.0f), 0.7f);
    private static final DustParticleOptions BONE_DUST = new DustParticleOptions(new Vector3f(0.95f, 0.92f, 0.82f), 0.8f);
    private static final int MAX_LIFE = 80;

    private float damage = 5f;
    private int homingTarget = -1; // magatama: the creature it curves toward
    private int reflectedBy = -1;  // a Gunbai sent it back: it doesn't hit the guard again on its way out

    public JutsuProjectile(EntityType<? extends JutsuProjectile> type, Level level) {
        super(type, level);
    }

    public static JutsuProjectile shoot(ServerPlayer owner, Kind kind, float speed, float yawOffset, float damage) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        Vec3 eye = owner.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        p.shootFromRotation(owner, owner.getXRot(), owner.getYRot() + yawOffset, 0.0f, speed, 0.5f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /**
     * Fired by any creature (e.g. a shadow clone) at a target; the damage is credited to {@code owner}
     * (the clone's player), so it counts as theirs and never hits them or their own clones.
     */
    public static JutsuProjectile shootAt(LivingEntity shooter, @javax.annotation.Nullable Entity owner, Kind kind, float speed,
                                          float damage, LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), shooter.level());
        p.setOwner(owner != null ? owner : shooter);
        Vec3 eye = shooter.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        Vec3 aim = target.getBoundingBox().getCenter().subtract(p.position());
        p.shoot(aim.x, aim.y, aim.z, speed, 0.5f);
        shooter.level().addFreshEntity(p);
        return p;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(KIND, (byte) 0);
        this.entityData.define(SCALE, 1.0f);
        this.entityData.define(COLOR, 0x8A55FF);
        this.entityData.define(AIM, new Vector3f());
    }

    /**
     * The Water Dragon: rises out of the ground at {@code from} (in front of the caster), then curves over to
     * {@code aim} and flies on through it until it hits something.
     */
    public static JutsuProjectile waterDragon(ServerPlayer owner, Vec3 from, Vec3 aim, float damage, float scale) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.WATER_DRAGON);
        p.damage = damage;
        p.setScale(scale);
        p.entityData.set(AIM, new Vector3f((float) aim.x, (float) aim.y, (float) aim.z));
        p.setDeltaMovement(0, 0.6, 0);
        owner.level().addFreshEntity(p);
        return p;
    }

    private boolean dragonPastAim;

    /** Water Dragon: where it's flying to (for the renderer). */
    public Vec3 dragonAim() {
        Vector3f a = this.entityData.get(AIM);
        return new Vec3(a.x(), a.y(), a.z());
    }

    /** Water Dragon steering, run the same on both sides so the curve looks smooth everywhere. */
    private void steerDragon() {
        Vector3f a = this.entityData.get(AIM);
        Vec3 aim = new Vec3(a.x(), a.y(), a.z());
        Vec3 to = aim.subtract(position());
        if (tickCount < DRAGON_RISE) {
            Vec3 flat = new Vec3(to.x, 0, to.z);
            Vec3 side = flat.lengthSqr() > 1e-4 ? flat.normalize().scale(0.12) : Vec3.ZERO;
            setDeltaMovement(new Vec3(side.x, 0.62 - tickCount * 0.03, side.z));
            return;
        }
        if (to.lengthSqr() < 2.5 * 2.5) dragonPastAim = true;
        Vec3 v = getDeltaMovement();
        if (v.lengthSqr() < 1e-6) v = to;
        Vec3 dir = v.normalize();
        if (!dragonPastAim && to.lengthSqr() > 1e-4) dir = dir.lerp(to.normalize(), 0.3).normalize();
        setDeltaMovement(dir.scale(DRAGON_SPEED));
    }

    /** The Water Dragon's body trails far behind its head: drawn whenever any of it could be on screen. */
    @Override
    public net.minecraft.world.phys.AABB getBoundingBoxForCulling() {
        if (getKind() == Kind.WATER_DRAGON) return getBoundingBox().inflate(10.0 * getScale());
        return super.getBoundingBoxForCulling();
    }

    /**
     * A Susanoo's magatama (Humanoid stage): flies from {@code from} along {@code dir} and curves toward
     * {@code target} (or the nearest creature ahead), in the owner's chakra colour.
     */
    public static JutsuProjectile magatama(ServerPlayer owner, Vec3 from, Vec3 dir, float damage, int color,
                                           @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.MAGATAMA);
        p.damage = damage;
        p.entityData.set(COLOR, color & 0xFFFFFF);
        p.homingTarget = target == null ? -1 : target.getId();
        p.shoot(dir.x, dir.y, dir.z, 1.6f, 0.0f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /**
     * Sent back by a guarding Gunbai: it now belongs to the guard, flies along {@code velocity} for a full lifetime,
     * and a magatama curves toward whoever threw it.
     */
    public void reflect(Entity guard, Vec3 velocity) {
        Entity thrower = getOwner();
        setOwner(guard);
        reflectedBy = guard.getId();
        homingTarget = thrower != null && thrower != guard ? thrower.getId() : -1;
        tickCount = 0;
        setDeltaMovement(velocity);
        hasImpulse = true;
    }

    /** Magatama: turn toward the target (or the nearest creature ahead within 32 blocks). */
    private void home() {
        Entity t = homingTarget >= 0 ? level().getEntity(homingTarget) : null;
        if (!(t instanceof net.minecraft.world.entity.LivingEntity lt) || !lt.isAlive()) {
            t = null;
            Vec3 ahead = getDeltaMovement().normalize();
            double best = 32 * 32;
            for (net.minecraft.world.entity.LivingEntity c : level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,
                    getBoundingBox().inflate(32), c -> JutsuUtil.isValidTarget(getOwner(), c))) {
                Vec3 to = c.getBoundingBox().getCenter().subtract(position());
                double d2 = to.lengthSqr();
                if (d2 < best && to.normalize().dot(ahead) > 0.3) {
                    best = d2;
                    t = c;
                }
            }
            homingTarget = t == null ? -1 : t.getId();
        }
        if (t == null) return;
        Vec3 want = t.getBoundingBox().getCenter().subtract(position()).normalize().scale(1.6);
        Vec3 v = getDeltaMovement().lerp(want, 0.25);
        setDeltaMovement(v.normalize().scale(1.6));
    }

    /** Size multiplier (1 = normal). The Great Fireball's is about 0.45 for a tap and 2.6 at full charge. */
    public float getScale() {
        return this.entityData.get(SCALE);
    }

    public void setScale(float scale) {
        this.entityData.set(SCALE, Mth.clamp(scale, 0.1f, 8f));
        refreshDimensions();
    }

    @Override
    public net.minecraft.world.entity.EntityDimensions getDimensions(net.minecraft.world.entity.Pose pose) {
        return super.getDimensions(pose).scale(getScale());
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SCALE.equals(key)) refreshDimensions();
    }

    public Kind getKind() {
        int i = this.entityData.get(KIND);
        return Kind.values()[Mth.clamp(i, 0, Kind.values().length - 1)];
    }

    public void setKind(Kind kind) {
        this.entityData.set(KIND, (byte) kind.ordinal());
    }

    private boolean isFire() {
        Kind k = getKind();
        return k == Kind.FIRE_BALL || k == Kind.FIRE_SMALL;
    }

    @Override
    protected float getGravity() {
        return 0.0f;
    }

    @Override
    public void tick() {
        if (!level().isClientSide && getKind() == Kind.MAGATAMA && tickCount > 3) home();
        if (getKind() == Kind.WATER_DRAGON) steerDragon();
        super.tick();
        if (level().isClientSide) {
            spawnTrail();
            return;
        }
        if (isRemoved()) return;
        if (isFire() && isInWaterOrBubble()) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 10, 0.2, 0.2, 0.2, 0.02);
            playSound(SoundEvents.FIRE_EXTINGUISH, 0.6f, 1.2f);
            discard();
        } else if (tickCount > MAX_LIFE) {
            discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (!super.canHitEntity(target)) return false;
        if (target.getId() == reflectedBy && tickCount < 10) return false;
        if (target instanceof net.minecraft.server.level.ServerPlayer sp) { // Kamui: jutsu pass through
            com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(sp);
            if (d != null && d.isIntangible(level().getGameTime())) return false;
        }
        Entity owner = getOwner();
        if (owner == null) return true;
        if (target == owner) return false;
        if (target instanceof SusanooEntity susanoo && susanoo.getOwnerId() == owner.getId()) return false; // its own Susanoo
        return !(target instanceof ShadowClone clone && owner.getUUID().equals(clone.getOwnerUUID()));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        Kind kind = getKind();
        if (kind == Kind.FIRE_SMALL) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.setSecondsOnFire(4);
        } else if (kind == Kind.WATER_BULLET) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.clearFire();
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(0.8).add(0, 0.2, 0));
        } else if (kind == Kind.MAGATAMA) {
            if (target instanceof LivingEntity living) living.invulnerableTime = 0; // the three each count
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(0.5).add(0, 0.2, 0));
        } else if (kind == Kind.ICE_NEEDLE || kind == Kind.BONE_BULLET) {
            if (target instanceof LivingEntity living) living.invulnerableTime = 0; // a volley: every needle / bullet counts
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            if (kind == Kind.ICE_NEEDLE && target instanceof LivingEntity living) {
                living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                living.setTicksFrozen(Math.min(living.getTicksRequiredToFreeze() + 40, living.getTicksFrozen() + 50)); // frost creeps in
            }
        }
        // FIRE_BALL, WATER_DRAGON, RASENGAN and RASENSHURIKEN deal area damage in impact().
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide && !isRemoved()) {
            impact(result.getLocation());
            discard();
        }
    }

    private void impact(Vec3 pos) {
        ServerLevel level = (ServerLevel) level();
        Entity owner = getOwner();
        switch (getKind()) {
            case FIRE_BALL -> {
                float s = getScale(); // small tap: ~2 block blast, full charge: ~5.4
                double radius = 1.5 + 1.5 * s;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, radius)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.setSecondsOnFire(Math.round(3 + 2 * s));
                }
                double spread = 0.5 + 0.6 * s;
                level.sendParticles(s > 1.8f ? ParticleTypes.EXPLOSION_EMITTER : ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z,
                        s > 1.8f ? 1 : 2, 0.5, 0.5, 0.5, 0.0);
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, Math.round(40 + 45 * s), spread, spread * 0.8, spread, 0.06 + 0.02 * s);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, Math.round(10 + 10 * s), spread, spread * 0.7, spread, 0.02);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.6f + 0.4f * s, 1.5f - 0.3f * s);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, Math.max(1, Math.round(s * 1.3f)), Math.round(4 + 4 * s));
            }
            case FIRE_SMALL -> {
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.03);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIRECHARGE_USE, getSoundSource(), 0.5f, 1.4f);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, 0, 1);
            }
            case WATER_BULLET -> {
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 30, 0.4, 0.4, 0.4, 0.1);
                level.sendParticles(WATER_DUST, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH, getSoundSource(), 0.7f, 1.5f);
            }
            case RASENGAN -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 2.2)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    JutsuUtil.push(e, push.scale(1.8).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.sendParticles(CHAKRA_DUST, pos.x, pos.y, pos.z, 50, 0.6, 0.6, 0.6, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 0.5, 0.3, 0.5, 0.08);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.8f, 1.5f);
            }
            case RASENSHURIKEN -> {
                // A sphere of wind blades: heavy damage all around the impact, slowing and throwing everything out.
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 5.0)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
                    Vec3 away = e.position().subtract(pos);
                    away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
                    JutsuUtil.push(e, away.scale(1.3).add(0, 0.6, 0));
                }
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y, pos.z, 40, 2.5, 1.8, 2.5, 0.0);
                level.sendParticles(WIND_DUST, pos.x, pos.y, pos.z, 120, 2.8, 2.0, 2.8, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 60, 2.5, 1.5, 2.5, 0.1);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 1.6f, 0.8f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ELYTRA_FLYING, getSoundSource(), 1.2f, 1.6f);
            }
            case MAGATAMA -> {
                level.sendParticles(colorDust(2.4f), pos.x, pos.y, pos.z, 30, 0.4, 0.4, 0.4, 0.0);
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.6f, 1.5f);
            }
            case ICE_NEEDLE -> {
                level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                        net.minecraft.world.level.block.Blocks.PACKED_ICE.defaultBlockState()), pos.x, pos.y, pos.z, 6, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, getSoundSource(), 0.25f, 1.8f);
            }
            case BONE_BULLET -> {
                level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                        net.minecraft.world.level.block.Blocks.BONE_BLOCK.defaultBlockState()), pos.x, pos.y, pos.z, 8, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BONE_BLOCK_BREAK, getSoundSource(), 0.6f, 1.4f);
            }
            case WATER_DRAGON -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 4.0)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.clearFire();
                    Vec3 away = e.position().subtract(pos).multiply(1, 0, 1);
                    away = away.lengthSqr() < 1e-4 ? push : away.normalize();
                    JutsuUtil.push(e, away.scale(1.2).add(push.scale(0.8)).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 150, 2.0, 1.2, 2.0, 0.3);
                level.sendParticles(WATER_DUST_BIG, pos.x, pos.y, pos.z, 60, 1.5, 1.0, 1.5, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 1.5, 0.5, 1.5, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, getSoundSource(), 1.5f, 0.6f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_SPLASH, getSoundSource(), 1.5f, 0.8f);
            }
        }
    }

    private void placeFire(ServerLevel level, Vec3 pos, int radius, int attempts) {
        RandomSource r = level.getRandom();
        for (int i = 0; i < attempts; i++) {
            BlockPos bp = BlockPos.containing(pos.x + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius),
                    pos.y + 0.5, pos.z + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius));
            for (int k = 0; k < 3; k++, bp = bp.below()) {
                if (BaseFireBlock.canBePlacedAt(level, bp, Direction.UP)) {
                    level.setBlockAndUpdate(bp, BaseFireBlock.getState(level, bp));
                    break;
                }
            }
        }
    }

    private DustParticleOptions colorDust(float size) {
        int c = this.entityData.get(COLOR);
        return new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f), Math.max(0.3f, size));
    }

    /** Client-side visuals. */
    private void spawnTrail() {
        Level level = level();
        RandomSource r = this.random;
        double x = getX(), y = getY() + getBbHeight() / 2, z = getZ();
        switch (getKind()) {
            case FIRE_BALL -> {
                float s = getScale();
                double spread = 0.9 * s;
                for (int i = 0; i < Math.round(3 + 4 * s); i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * spread, y + (r.nextDouble() - 0.5) * spread,
                            z + (r.nextDouble() - 0.5) * spread, 0, 0.01, 0);
                }
                level.addParticle(ParticleTypes.LARGE_SMOKE, x, y, z, 0, 0.02, 0);
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.LAVA, x, y, z, 0, 0, 0);
            }
            case FIRE_SMALL -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SMOKE, x, y, z, 0, 0, 0);
            }
            case WATER_BULLET -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(WATER_DUST, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SPLASH, x, y, z, 0, 0, 0);
            }
            case RASENGAN -> {
                for (int i = 0; i < 6; i++) {
                    double a = (tickCount * 0.9 + i * Math.PI / 3);
                    level.addParticle(CHAKRA_DUST, x + Math.cos(a) * 0.3, y + Math.sin(a * 1.3) * 0.25, z + Math.sin(a) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.ENCHANTED_HIT, x, y, z, 0, 0, 0);
            }
            case RASENSHURIKEN -> {
                for (int i = 0; i < 4; i++) {
                    double a = tickCount * 1.2 + i * Math.PI / 2;
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 1.2, y, z + Math.sin(a) * 1.2, 0, 0, 0);
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 0.6, y, z + Math.sin(a) * 0.6, 0, 0, 0);
                }
                level.addParticle(CHAKRA_DUST, x, y, z, 0, 0, 0);
                if (r.nextInt(2) == 0) level.addParticle(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0, 0);
            }
            case MAGATAMA -> { // a fat head with a curling tail, like the comma shape
                Vec3 step = getDeltaMovement();
                DustParticleOptions dust = colorDust(1.8f);
                for (int i = 0; i < 3; i++) level.addParticle(dust, x + (r.nextDouble() - 0.5) * 0.4, y + (r.nextDouble() - 0.5) * 0.4, z + (r.nextDouble() - 0.5) * 0.4, 0, 0, 0);
                for (int i = 1; i <= 4; i++) {
                    double a = tickCount * 0.9 + i * 0.6, f = i / 4.0;
                    level.addParticle(colorDust(1.3f - 0.2f * i), x - step.x * f + Math.cos(a) * 0.35 * f, y - step.y * f + Math.sin(a) * 0.35 * f,
                            z - step.z * f, 0, 0, 0);
                }
            }
            case ICE_NEEDLE, BONE_BULLET -> { // fast and small: a streak of dust along the whole step so they read as needles
                Vec3 step = getDeltaMovement();
                DustParticleOptions dust = getKind() == Kind.ICE_NEEDLE ? ICE_DUST : BONE_DUST;
                for (int i = 0; i < 4; i++) {
                    double f = i / 4.0;
                    level.addParticle(dust, x - step.x * f, y - step.y * f, z - step.z * f, 0, 0, 0);
                }
                if (getKind() == Kind.ICE_NEEDLE && r.nextInt(3) == 0) level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0, 0, 0);
            }
            case WATER_DRAGON -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(WATER_DUST_BIG, x + (r.nextDouble() - 0.5) * 1.6, y + (r.nextDouble() - 0.5) * 1.6,
                            z + (r.nextDouble() - 0.5) * 1.6, 0, 0, 0);
                }
                for (int i = 0; i < 4; i++) {
                    level.addParticle(ParticleTypes.SPLASH, x + (r.nextDouble() - 0.5) * 1.2, y + (r.nextDouble() - 0.5) * 1.2,
                            z + (r.nextDouble() - 0.5) * 1.2, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.CLOUD, x, y, z, 0, 0, 0);
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("Kind", (byte) getKind().ordinal());
        tag.putFloat("Damage", damage);
        tag.putFloat("Scale", getScale());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(KIND, tag.getByte("Kind"));
        this.damage = tag.getFloat("Damage");
        if (tag.contains("Scale")) setScale(tag.getFloat("Scale"));
    }
}
