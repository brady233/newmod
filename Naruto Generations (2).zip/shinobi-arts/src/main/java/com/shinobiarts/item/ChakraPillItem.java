package com.shinobiarts.item;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Restores chakra when eaten. */
public class ChakraPillItem extends Item {
    /** Chakra restored ("chakraPillRestore" in Food.toml). */
    public static float restore() {
        return com.shinobiarts.Config.f(com.shinobiarts.Config.CHAKRA_PILL_RESTORE);
    }

    public ChakraPillItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (entity instanceof ServerPlayer sp) {
            NinjaData data = NinjaData.get(sp);
            if (data != null) {
                data.addChakra(restore());
                sp.displayClientMessage(Component.translatable("message.shinobiarts.pill", (int) restore()).withStyle(ChatFormatting.AQUA), true);
                ModNetwork.sync(sp);
            }
        }
        return super.finishUsingItem(stack, level, entity);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.chakra_pill", (int) restore()).withStyle(ChatFormatting.GRAY));
    }
}
