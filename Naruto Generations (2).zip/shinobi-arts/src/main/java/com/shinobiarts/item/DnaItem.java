package com.shinobiarts.item;

import com.shinobiarts.client.ClientNinjaData;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.KekkeiGenkai;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A vial of DNA. Either one kekkei genkai (Wood, Ice, Magnet, Bone, Sealing, Sharingan, Byakugan: awakens it with its
 * whole skillset) or one chakra nature (Fire, Water, Wind, Lightning, Earth, Yin Yang: unlocks that release, like a
 * nature scroll). Dropped by the mobs set in "Spawn weights and chances.toml" and by defeated players.
 */
public class DnaItem extends Item {
    @Nullable
    private final KekkeiGenkai kekkeiGenkai;
    @Nullable
    private final ChakraNature nature;

    public DnaItem(KekkeiGenkai kekkeiGenkai, Properties properties) {
        super(properties);
        this.kekkeiGenkai = kekkeiGenkai;
        this.nature = null;
    }

    public DnaItem(ChakraNature nature, Properties properties) {
        super(properties);
        this.kekkeiGenkai = null;
        this.nature = nature;
    }

    @Nullable
    public KekkeiGenkai kekkeiGenkai() {
        return kekkeiGenkai;
    }

    @Nullable
    public ChakraNature nature() {
        return nature;
    }

    private MutableComponent label() {
        return kekkeiGenkai != null ? kekkeiGenkai.shortName() : nature.displayName();
    }

    private boolean has(NinjaData d) {
        return kekkeiGenkai != null ? kekkeiGenkai.has(d) : d.hasNature(nature);
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable("item.shinobiarts.dna", label());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        NinjaData d = NinjaData.get(sp);
        if (d == null) return InteractionResultHolder.pass(stack);
        if (kekkeiGenkai != null) {
            if (kekkeiGenkai.has(d)) {
                sp.displayClientMessage(Component.translatable("message.shinobiarts.kekkei_genkai_known", label())
                        .withStyle(ChatFormatting.GRAY), true);
                return InteractionResultHolder.fail(stack);
            }
            if (KekkeiGenkai.awaken(sp, kekkeiGenkai) && !player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResultHolder.consume(stack);
        }

        // a chakra nature: the same rules as a nature scroll
        if (!d.isAffinityRevealed()) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.need_affinity").withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }
        if (d.hasNature(nature)) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.already_have_nature", label()).withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        d.unlockNature(nature);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        sp.sendSystemMessage(Component.translatable("message.shinobiarts.nature_unlocked", label()).withStyle(ChatFormatting.GREEN));
        ReleaseItem.give(sp, nature);
        sp.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.4, 0.7, 0.4, 0.35);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_LEVELUP, sp.getSoundSource(), 1.0f, 0.7f);
        ModNetwork.sync(sp);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (kekkeiGenkai != null) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.dna", label()).withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable(kekkeiGenkai.release() != null ? "tooltip.shinobiarts.dna_release" : "tooltip.shinobiarts.dna_eyes")
                    .withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.shinobiarts.dna_nature", label()).withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("tooltip.shinobiarts.nature_scroll_req").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        }
        if (level != null && level.isClientSide && has(ClientNinjaData.get())) {
            tooltip.add(Component.translatable(kekkeiGenkai != null ? "tooltip.shinobiarts.dna_have" : "tooltip.shinobiarts.dna_have_nature")
                    .withStyle(ChatFormatting.GREEN));
        } else {
            tooltip.add(Component.translatable("tooltip.shinobiarts.dna_use").withStyle(ChatFormatting.YELLOW));
        }
    }
}
