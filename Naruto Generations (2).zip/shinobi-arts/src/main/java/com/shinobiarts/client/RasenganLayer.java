package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.HumanoidArm;

/** The Rasengan on a player's fist (third person, and everyone else's view of you): see RasenganRender. */
public class RasenganLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public RasenganLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int light, AbstractClientPlayer player, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !player.getMainHandItem().isEmpty()) return;
        float age = RasenganRender.age(player, partialTick);
        if (age < 0) return;
        float size = RasenganRender.size(age);
        if (size <= 0f) return;
        HumanoidArm arm = player.getMainArm();
        poseStack.pushPose();
        getParentModel().translateToHand(arm, poseStack);
        // just past the fist (the player model is drawn at 0.9375 scale; the ball keeps its own size)
        float radius = size * 0.6f / 0.9375f * 16f;
        poseStack.translate((arm == HumanoidArm.RIGHT ? -1f : 1f) / 16f, (10.5f + radius) / 16f, 0f);
        poseStack.scale(1f / 0.9375f, 1f / 0.9375f, 1f / 0.9375f);
        RasenganRender.drawBall(poseStack, buffer, size, age);
        poseStack.popPose();
    }
}
