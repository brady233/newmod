package com.shinobiarts.client;

import com.shinobiarts.network.BoardActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.quest.QuestItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * The Kage menu (/village &lt;village&gt; admin): post a quest for the item in your hand (amount and reward),
 * remove posted quests, promote or demote online members, appoint Village Advisors ("A"), and open the village
 * storage where handed-in items go.
 */
public class KageScreen extends Screen {
    private static final int W = 380, H = 240, ROWS = 5, ROW_Y = 148, ROW_H = 16;

    private CompoundTag board;
    private EditBox amount;
    private EditBox bottles;
    private EditBox ryo;
    private Button postButton;
    private long openedAt = System.currentTimeMillis();
    private int left;
    private int top;

    public KageScreen(CompoundTag board) {
        super(Component.translatable("screen.shinobiarts.kage_menu"));
        this.board = board;
    }

    public void update(CompoundTag board) {
        this.board = board;
        this.openedAt = System.currentTimeMillis();
        String a = amount == null ? "64" : amount.getValue(), b = bottles == null ? "2" : bottles.getValue(), r = ryo == null ? "500" : ryo.getValue();
        rebuildWidgets();
        amount.setValue(a);
        bottles.setValue(b);
        ryo.setValue(r);
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = Math.max(16, (this.height - H) / 2);
        int x = left + 8;
        amount = number(x + 48, top + 58, "64");
        bottles = number(x + 48, top + 76, "2");
        ryo = number(x + 48, top + 94, "500");
        postButton = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.post_quest"), b -> post())
                .bounds(x, top + 114, 160, 16).build());
        tick();

        ListTag quests = board.getList("kage", Tag.TAG_COMPOUND);
        for (int i = 0; i < Math.min(quests.size(), ROWS); i++) {
            int id = parseId(quests.getCompound(i).getString("Uid"));
            addRenderableWidget(Button.builder(Component.literal("x"),
                    b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.REMOVE, "", id, 0, 0)))
                    .bounds(x + 152, top + ROW_Y + i * ROW_H + 2, 12, 12).build());
        }

        ListTag members = board.getList("members", Tag.TAG_COMPOUND);
        int rx = left + 184;
        for (int i = 0; i < Math.min(members.size(), 10); i++) {
            CompoundTag m = members.getCompound(i);
            String name = m.getString("Name");
            boolean advisor = m.getBoolean("Advisor");
            int y = top + 30 + i * 16;
            addRenderableWidget(Button.builder(Component.literal("A").withStyle(advisor ? ChatFormatting.AQUA : ChatFormatting.WHITE),
                    b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.ADVISOR, name, 0, 0, 0)))
                    .bounds(rx + 136, y, 14, 13)
                    .tooltip(Tooltip.create(Component.translatable(advisor ? "screen.shinobiarts.advisor_remove" : "screen.shinobiarts.advisor_make")))
                    .build());
            addRenderableWidget(Button.builder(Component.literal("+"),
                    b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.PROMOTE, name, 1, 0, 0)))
                    .bounds(rx + 152, y, 14, 13).tooltip(Tooltip.create(Component.translatable("screen.shinobiarts.promote"))).build());
            addRenderableWidget(Button.builder(Component.literal("-"),
                    b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.PROMOTE, name, -1, 0, 0)))
                    .bounds(rx + 168, y, 14, 13).tooltip(Tooltip.create(Component.translatable("screen.shinobiarts.demote"))).build());
        }

        addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.village_storage"),
                b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.STORAGE, "", 0, 0, 0)))
                .bounds(rx, top + H - 22, 82, 16).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.quest_board"),
                b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.REFRESH, "", 0, 0, 0)))
                .bounds(rx + 86, top + H - 22, 82, 16).build());
    }

    private EditBox number(int x, int y, String value) {
        EditBox box = new EditBox(this.font, x, y, 62, 14, Component.empty());
        box.setFilter(s -> s.isEmpty() || s.matches("\\d{0,9}"));
        box.setValue(value);
        addRenderableWidget(box);
        return box;
    }

    private void post() {
        ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.POST, "", parse(amount), parse(bottles), parse(ryo)));
    }

    private static int parse(EditBox box) {
        try {
            return box.getValue().isEmpty() ? 0 : Integer.parseInt(box.getValue());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static int parseId(String uid) {
        try {
            return Integer.parseInt(uid.substring(2));
        } catch (RuntimeException e) {
            return -1;
        }
    }

    /** Seconds until this village's Kage may post another quest (one per kageQuestCooldownMinutes). */
    private long postWait() {
        return board.getLong("PostWait") - (System.currentTimeMillis() - openedAt) / 1000;
    }

    @Override
    public void tick() {
        if (postButton == null) return;
        long wait = postWait();
        postButton.active = wait <= 0;
        // while the Kage has to wait, the button says how long
        postButton.setMessage(wait > 0 ? Component.translatable("screen.shinobiarts.next_post", QuestBoardScreen.duration(wait))
                : Component.translatable("screen.shinobiarts.post_quest"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        StatScreen.panel(g, left, top, W, H);

        int x = left + 8;
        g.drawString(this.font, Component.translatable("screen.shinobiarts.kage_title", board.getString("Village")), x, top + 7, StatScreen.INK, false);
        g.fill(left + 176, top + 20, left + 177, top + H - 8, StatScreen.LINE);

        // post a quest
        g.drawString(this.font, Component.translatable("screen.shinobiarts.post_header"), x, top + 22, StatScreen.INK_SOFT, false);
        ItemStack held = this.minecraft.player == null ? ItemStack.EMPTY : this.minecraft.player.getMainHandItem();
        if (held.isEmpty()) {
            g.drawString(this.font, Component.translatable("screen.shinobiarts.hold_item"), x, top + 38, 0xFFA01818, false);
        } else {
            g.renderItem(held, x, top + 34);
            g.drawString(this.font, held.getHoverName(), x + 20, top + 38, StatScreen.INK, false);
        }
        g.drawString(this.font, Component.translatable("screen.shinobiarts.amount"), x, top + 61, StatScreen.INK, false);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.exp_bottles"), x, top + 79, StatScreen.INK, false);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.ryo_reward"), x, top + 97, StatScreen.INK, false);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.max", board.getInt("MaxBottles")), x + 116, top + 79, StatScreen.INK_SOFT, false);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.max", PlayerDataManager.formatRyo(board.getInt("MaxRyo"))),
                x + 116, top + 97, StatScreen.INK_SOFT, false);

        // posted quests
        g.drawString(this.font, Component.translatable("screen.shinobiarts.posted_quests"), x, top + 136, StatScreen.INK_SOFT, false);
        ListTag quests = board.getList("kage", Tag.TAG_COMPOUND);
        for (int i = 0; i < Math.min(quests.size(), ROWS); i++) {
            CompoundTag q = quests.getCompound(i);
            int y = top + ROW_Y + i * ROW_H;
            g.renderFakeItem(new ItemStack(QuestItems.icon(q.getString("Item"))), x, y);
            Component line = Component.translatable("screen.shinobiarts.posted_line", q.getInt("Count"), q.getInt("Bottles"),
                    PlayerDataManager.formatRyo(q.getLong("Ryo")));
            g.drawString(this.font, line, x + 18, y + 4, StatScreen.INK, false);
        }
        if (quests.size() > ROWS) {
            g.drawString(this.font, Component.translatable("screen.shinobiarts.more", quests.size() - ROWS), x, top + ROW_Y + ROWS * ROW_H,
                    StatScreen.INK_SOFT, false);
        }
        if (quests.isEmpty()) g.drawString(this.font, Component.translatable("screen.shinobiarts.none_posted"), x, top + ROW_Y + 4, StatScreen.INK_SOFT, false);

        // members
        int rx = left + 184;
        g.drawString(this.font, Component.translatable("screen.shinobiarts.members_online"), rx, top + 18, StatScreen.INK_SOFT, false);
        ListTag members = board.getList("members", Tag.TAG_COMPOUND);
        for (int i = 0; i < Math.min(members.size(), 10); i++) {
            CompoundTag m = members.getCompound(i);
            int y = top + 30 + i * 16;
            String info = m.getString("Rank") + " " + m.getInt("Level");
            int infoW = this.font.width(info);
            String name = this.font.plainSubstrByWidth(m.getString("Name") + (m.getBoolean("Kage") ? " ★" : ""), 132 - infoW - 4);
            g.drawString(this.font, name, rx, y + 3, m.getBoolean("Advisor") ? 0xFF1F6F8F : StatScreen.INK, false);
            g.drawString(this.font, info, rx + 132 - infoW, y + 3, StatScreen.INK_SOFT, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
