package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The Rasengan, drawn from OPREXT's model (meshes/rasengan.bin): when it's cast, two shadow clones (wearing the
 * caster's skin) pop out of smoke on either side, cup their hands round the caster's palm while the ball grows and
 * spins faster, then vanish in smoke; after that it sits on the fist until it hits something. Everyone nearby sees it
 * (the look bits say who has one and who is still forming it). Purely visual: the server does the rest.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class RasenganRender {
    private RasenganRender() {}

    /** The model's scale once formed (its shells span about ±0.71, so roughly a block across). */
    public static final float FULL_SIZE = 0.85f;
    private static final int FORM = NinjaData.RASENGAN_FORM_TICKS, HOLD = NinjaData.RASENGAN_HOLD_TICKS;
    /** Ticks into the forming when the clones appear and when they vanish. */
    private static final float CLONES_IN = 1f, CLONES_OUT = 25f;
    private static final ResourceLocation[] SHELLS = {tex("shell_0"), tex("shell_1")};
    private static final ResourceLocation CORE = tex("core"), HALO = tex("halo");

    /** When each player we can see started forming theirs (client time), and whose clones have already gone. */
    private static final Map<Integer, Long> START = new HashMap<>();
    private static final Set<Integer> GONE = new HashSet<>();

    /** The holding arm: reaching in toward the clones while it forms, then held out in front. */
    public static final HumanoidModel.ArmPose POSE = HumanoidModel.ArmPose.create("SHINOBIARTS_RASENGAN", false, (model, entity, arm) -> {
        float age = entity instanceof Player p ? age(p, Minecraft.getInstance().getFrameTime()) : FORM;
        float hold = smooth(clamp01((age / FORM - 0.74f) / 0.14f));
        ModelPart part = arm == HumanoidArm.RIGHT ? model.rightArm : model.leftArm;
        float side = arm == HumanoidArm.RIGHT ? 1f : -1f;
        part.xRot = Mth.lerp(hold, -62f, -82f) * Mth.DEG_TO_RAD;
        part.yRot = side * Mth.lerp(hold, -16f, -6f) * Mth.DEG_TO_RAD;
        part.zRot = 0f;
    });

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(ShinobiArts.MODID, "textures/entity/rasengan/" + name + ".png");
    }

    private static float clamp01(float v) {
        return Mth.clamp(v, 0f, 1f);
    }

    private static float smooth(float x) {
        return x * x * (3 - 2 * x);
    }

    // ---------------------------------------------------------------- state

    /** Ticks since this player cast their Rasengan (it forms over the first FORM ticks), or -1 if they have none. */
    public static float age(Player player, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return -1;
        int look = ClientEyes.look(player);
        if ((look & SharinganManager.LOOK_RASENGAN) == 0) return -1;
        long now = mc.level.getGameTime();
        if (player == mc.player) {
            long cast = ClientNinjaData.get().getRasenganUntil() - FORM - HOLD;
            return Math.max(0f, now - cast + partial);
        }
        Long start = START.get(player.getId());
        boolean forming = (look & SharinganManager.LOOK_RASENGAN_FORMING) != 0;
        if (start == null) return forming ? 0f : FORM + 40f;
        float age = now - start + partial;
        return forming ? Math.min(age, FORM - 0.01f) : Math.max(age, FORM);
    }

    /** The ball's scale at {@code age} ticks: nothing for a moment, then it grows quickly and settles. */
    public static float size(float age) {
        float t = age / FORM;
        if (t < 0.12f) return 0f;
        float k = clamp01((t - 0.12f) / 0.6f);
        return FULL_SIZE * (0.06f + 0.94f * (1 - (1 - k) * (1 - k) * (1 - k)));
    }

    /** How far it has turned (degrees): spinning up while it forms, then fast and steady. */
    private static float spin(float age) {
        return age < FORM ? 9f * age * age / FORM : 9f * FORM + 18f * (age - FORM);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            START.clear();
            GONE.clear();
            return;
        }
        if (mc.isPaused()) return;
        long now = mc.level.getGameTime();
        Set<Integer> seen = new HashSet<>();
        for (AbstractClientPlayer p : mc.level.players()) {
            int id = p.getId();
            int look = ClientEyes.look(p);
            if ((look & SharinganManager.LOOK_RASENGAN) == 0) continue;
            seen.add(id);
            boolean forming = (look & SharinganManager.LOOK_RASENGAN_FORMING) != 0;
            if (!START.containsKey(id)) {
                if (!forming) {                                   // already formed when we first saw it: no clones
                    START.put(id, now - FORM - 40L);
                    GONE.add(id);
                    continue;
                }
                long start = p == mc.player ? now - (long) age(p, 0f) : now;
                START.put(id, start);
                if (now - start <= 4) puffs(p, false);
            }
            if (!GONE.contains(id) && age(p, 0f) >= CLONES_OUT) {
                GONE.add(id);
                puffs(p, true);
            }
        }
        START.keySet().retainAll(seen);
        GONE.retainAll(seen);
    }

    // ---------------------------------------------------------------- the clones

    private record Spot(double x, double y, double z, float yaw) {}

    /** Where the two clones stand: either side of the caster's palm and a little past it, turned to face it. */
    private static Spot[] clones(Player p, float partial) {
        Minecraft mc = Minecraft.getInstance();
        boolean firstPerson = p == mc.player && mc.options.getCameraType().isFirstPerson();
        float yaw = firstPerson ? p.getViewYRot(partial) : Mth.rotLerp(partial, p.yBodyRotO, p.yBodyRot);
        double r = Math.toRadians(yaw);
        double fx = -Math.sin(r), fz = Math.cos(r), rx = -Math.cos(r), rz = -Math.sin(r);
        double hand = p.getMainArm() == HumanoidArm.RIGHT ? 0.2 : -0.2;
        Vec3 pos = p.getPosition(partial);
        double cx = pos.x + fx * 0.7 + rx * hand, cz = pos.z + fz * 0.7 + rz * hand;
        Spot[] out = new Spot[2];
        for (int i = 0; i < 2; i++) {
            double s = i == 0 ? -1 : 1;
            double x = cx + rx * 1.03 * s + fx * 0.3, z = cz + rz * 1.03 * s + fz * 0.3;
            out[i] = new Spot(x, pos.y, z, (float) Math.toDegrees(Math.atan2(-(cx - x), cz - z)));
        }
        return out;
    }

    /** The shadow clones' poof, as they appear and as they go. */
    private static void puffs(Player p, boolean vanish) {
        if (!(p.level() instanceof ClientLevel level)) return;
        for (Spot s : clones(p, 1f)) {
            for (int i = 0; i < 16; i++) {
                level.addParticle(ParticleTypes.POOF, s.x + (level.random.nextDouble() - 0.5) * 0.7, s.y + 0.1 + level.random.nextDouble() * 1.8,
                        s.z + (level.random.nextDouble() - 0.5) * 0.7, 0, 0.02, 0);
            }
            for (int i = 0; i < 4; i++) {
                level.addParticle(ParticleTypes.CLOUD, s.x, s.y + 0.5 + level.random.nextDouble(), s.z,
                        (level.random.nextDouble() - 0.5) * 0.1, 0.03, (level.random.nextDouble() - 0.5) * 0.1);
            }
            if (vanish) level.playLocalSound(s.x, s.y + 1, s.z, SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.45f, 1.7f, false);
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float partial = event.getPartialTick();
        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        for (AbstractClientPlayer p : mc.level.players()) {
            if (p.isInvisible() || GONE.contains(p.getId())) continue;
            float age = age(p, partial);
            if (age < CLONES_IN || age > CLONES_OUT + 1.5f) continue;
            EntityRenderer<? super AbstractClientPlayer> r = mc.getEntityRenderDispatcher().getRenderer(p);
            if (!(r instanceof PlayerRenderer renderer)) continue;
            float alpha = clamp01((age - CLONES_IN) / 3f) * clamp01((CLONES_OUT + 1.5f - age) / 2f);
            RenderType type = RenderType.entityTranslucent(p.getSkinTextureLocation());
            VertexConsumer vc = buffers.getBuffer(type);
            Spot[] spots = clones(p, partial);
            for (int i = 0; i < spots.length; i++) {
                Spot s = spots[i];
                ps.pushPose();
                ps.translate(s.x - cam.x, s.y - cam.y, s.z - cam.z);
                ps.mulPose(Axis.YP.rotationDegrees(180f - s.yaw));
                ps.scale(-1f, -1f, 1f);
                ps.scale(0.9375f, 0.9375f, 0.9375f);
                ps.translate(0f, -1.501f, 0f);
                PlayerModel<AbstractClientPlayer> model = renderer.getModel();
                poseClone(model, p, age, i == 0 ? -1 : 1);
                int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(s.x, s.y + 1, s.z));
                model.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, alpha);
                ps.popPose();
            }
            buffers.endBatch(type);
        }
    }

    /** A clone standing straight, looking down at the palm, both hands circling round it. */
    private static void poseClone(PlayerModel<?> m, Player p, float age, int side) {
        m.setAllVisible(true);
        m.hat.visible = p.isModelPartShown(PlayerModelPart.HAT);
        m.jacket.visible = p.isModelPartShown(PlayerModelPart.JACKET);
        m.leftPants.visible = p.isModelPartShown(PlayerModelPart.LEFT_PANTS_LEG);
        m.rightPants.visible = p.isModelPartShown(PlayerModelPart.RIGHT_PANTS_LEG);
        m.leftSleeve.visible = p.isModelPartShown(PlayerModelPart.LEFT_SLEEVE);
        m.rightSleeve.visible = p.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE);
        float d = Mth.DEG_TO_RAD;
        m.head.setPos(0f, 0f, 0f);
        m.head.setRotation(25f * d, 0f, 0f);
        m.body.setPos(0f, 0f, 0f);
        m.body.setRotation(0f, 0f, 0f);
        m.rightLeg.setPos(-1.9f, 12f, 0.1f);
        m.rightLeg.setRotation(0f, 0f, 0f);
        m.leftLeg.setPos(1.9f, 12f, 0.1f);
        m.leftLeg.setRotation(0f, 0f, 0f);
        float w = age * 1.27f + (side > 0 ? 0f : 1.6f);
        m.rightArm.setPos(m.rightArm.x, 2f, 0f);
        m.rightArm.setRotation((-74f + 9f * Mth.sin(w)) * d, (14f + 7f * Mth.cos(w)) * d, 0f);
        m.leftArm.setPos(m.leftArm.x, 2f, 0f);
        m.leftArm.setRotation((-74f + 9f * Mth.sin(w + 2.2f)) * d, (-14f - 7f * Mth.cos(w + 2.2f)) * d, 0f);
        m.hat.copyFrom(m.head);
        m.jacket.copyFrom(m.body);
        m.leftPants.copyFrom(m.leftLeg);
        m.rightPants.copyFrom(m.rightLeg);
        m.leftSleeve.copyFrom(m.leftArm);
        m.rightSleeve.copyFrom(m.rightArm);
    }

    // ---------------------------------------------------------------- the holding arm and the first-person view

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        if (!p.getMainHandItem().isEmpty() || age(p, event.getPartialTick()) < 0) return;
        PlayerModel<AbstractClientPlayer> model = event.getRenderer().getModel();
        if (p.getMainArm() == HumanoidArm.RIGHT) model.rightArmPose = POSE;
        else model.leftArmPose = POSE;
    }

    /** First person: your arm (brought in toward the middle while the clones work) with the ball on your fist. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || !event.getItemStack().isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || player.isInvisible()) return;
        float age = age(player, event.getPartialTick());
        if (age < 0) return;
        if (!(mc.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer renderer)) return;
        event.setCanceled(true);
        boolean right = player.getMainArm() == HumanoidArm.RIGHT;
        float f = right ? 1f : -1f;
        float lift = 1f - smooth(clamp01((age / FORM - 0.74f) / 0.14f));
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-0.3f * lift * f, 0f, -0.08f * lift);
        // the same arm vanilla draws for an empty hand (ItemInHandRenderer.renderPlayerArm)
        float swing = event.getSwingProgress(), equip = event.getEquipProgress();
        float s1 = Mth.sqrt(swing);
        ps.translate(f * (-0.3f * Mth.sin(s1 * Mth.PI) + 0.64000005f), 0.4f * Mth.sin(s1 * (Mth.PI * 2f)) - 0.6f + equip * -0.6f,
                -0.4f * Mth.sin(swing * Mth.PI) - 0.71999997f);
        ps.mulPose(Axis.YP.rotationDegrees(f * 45f));
        ps.mulPose(Axis.YP.rotationDegrees(f * Mth.sin(s1 * Mth.PI) * 70f));
        ps.mulPose(Axis.ZP.rotationDegrees(f * Mth.sin(swing * swing * Mth.PI) * -20f));
        ps.translate(f * -1f, 3.6f, 3.5f);
        ps.mulPose(Axis.ZP.rotationDegrees(f * 120f));
        ps.mulPose(Axis.XP.rotationDegrees(200f));
        ps.mulPose(Axis.YP.rotationDegrees(f * -135f));
        ps.translate(f * 5.6f, 0f, 0f);
        if (right) renderer.renderRightHand(ps, event.getMultiBufferSource(), event.getPackedLight(), player);
        else renderer.renderLeftHand(ps, event.getMultiBufferSource(), event.getPackedLight(), player);
        float size = size(age);
        ps.translate(-f * 5f / 16f, 2f / 16f, 0f);                           // the arm's pivot
        ps.translate(-f / 16f, (10.5f + size * 0.6f * 16f) / 16f, 0f);       // just past the fist
        drawBall(ps, event.getMultiBufferSource(), size, age);
        ps.popPose();
    }

    // ---------------------------------------------------------------- the ball

    /**
     * Draws the ball centred on the pose: the model's three textured shells, each spinning about its own axis, a white
     * core and a blue glow (both turned to the camera), and while it forms, wisps of chakra spiralling into it.
     */
    public static void drawBall(PoseStack ps, MultiBufferSource buffers, float size, float age) {
        if (size <= 0.001f) return;
        List<JutsuMesh.Group> groups = JutsuMesh.get("rasengan");
        Matrix4f base = new Matrix4f(ps.last().pose());
        float spin = spin(age);
        ps.pushPose();
        ps.scale(size, size, size);
        for (int i = 0; i < groups.size(); i++) {
            JutsuMesh.Group g = groups.get(i);
            ps.pushPose();
            if (i == 0) ps.mulPose(Axis.YP.rotationDegrees(spin * 1.7f));
            else if (i == 1) ps.mulPose(Axis.XP.rotationDegrees(spin * 1.1f));
            else ps.mulPose(Axis.ZP.rotationDegrees(spin * 1.3f));
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(SHELLS[Mth.clamp(g.texture(), 0, SHELLS.length - 1)]));
            JutsuMesh.draw(g, ps.last(), vc, 1f, 1f, 1f, Math.min(1f, g.opacity() * 1.5f), LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
            ps.popPose();
        }
        Matrix4f pose = ps.last().pose();
        Vector3f centre = pose.transformPosition(0f, 0f, 0f, new Vector3f());
        float unit = pose.transformDirection(1f, 0f, 0f, new Vector3f()).length();
        billboard(buffers.getBuffer(RenderType.entityTranslucentEmissive(CORE)), centre, 0.27f * unit, 1f, 0.9f);
        billboard(buffers.getBuffer(RenderType.eyes(HALO)), centre, 0.75f * unit, 0.45f, 1f);
        ps.popPose();
        float t = age / FORM;
        if (t < 0.8f) {                                                      // chakra wisps drawn in while it forms
            float baseUnit = base.transformDirection(1f, 0f, 0f, new Vector3f()).length();
            VertexConsumer wisps = buffers.getBuffer(RenderType.eyes(HALO));
            for (int i = 0; i < 16; i++) {
                float ph = (t * 2.6f + i / 16f) % 1f, a = i * 2.4f + t * 30f, rad = 0.95f * (1f - ph);
                Vector3f p = base.transformPosition(Mth.cos(a) * rad, Mth.sin(a * 0.7f) * rad * 0.35f, Mth.sin(a) * rad, new Vector3f());
                billboard(wisps, p, 0.08f * baseUnit, 0.9f * Mth.sin(ph * Mth.PI), 1f);
            }
        }
    }

    /** A square facing the camera (the pose is already in camera space), brightness {@code k}, alpha {@code a}. */
    private static void billboard(VertexConsumer vc, Vector3f c, float h, float k, float a) {
        Matrix4f m = new Matrix4f().translation(c);
        Matrix3f n = new Matrix3f();
        int light = LightTexture.FULL_BRIGHT, overlay = OverlayTexture.NO_OVERLAY;
        vc.vertex(m, -h, -h, 0f).color(k, k, k, a).uv(0f, 1f).overlayCoords(overlay).uv2(light).normal(n, 0f, 0f, 1f).endVertex();
        vc.vertex(m, h, -h, 0f).color(k, k, k, a).uv(1f, 1f).overlayCoords(overlay).uv2(light).normal(n, 0f, 0f, 1f).endVertex();
        vc.vertex(m, h, h, 0f).color(k, k, k, a).uv(1f, 0f).overlayCoords(overlay).uv2(light).normal(n, 0f, 0f, 1f).endVertex();
        vc.vertex(m, -h, h, 0f).color(k, k, k, a).uv(0f, 0f).overlayCoords(overlay).uv2(light).normal(n, 0f, 0f, 1f).endVertex();
    }
}
