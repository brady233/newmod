package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.EightGates;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The Eight Inner Gates on anyone who has them open: a rising aura around the body in each gate's colour (pale chakra,
 * then the Gate of Life's red, green at the Gate of View, blue at the Gate of Wonder, red steam at the Gate of Death),
 * and from the Gate of Life on, the skin flushes red and the veins stand out.
 */
public class GatesLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation AURA = new ResourceLocation(ShinobiArts.MODID, "textures/entity/gates_aura.png");
    private static final ResourceLocation VEINS = new ResourceLocation(ShinobiArts.MODID, "textures/entity/gates_veins.png");
    private final HumanoidModel<AbstractClientPlayer> shell;

    public GatesLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        this.shell = new HumanoidModel<>(models.bakeLayer(ClientSetup.GATES_AURA_LAYER));
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        int gates = SharinganManager.lookGates(ClientEyes.look(entity));
        if (gates <= 0 || entity.isInvisible()) return;

        // veins and flushed skin: faint at the first gates, standing out from the Gate of Life (3) on
        float veins = gates >= 3 ? Math.min(1f, 0.45f + (gates - 3) * 0.11f) : 0.12f * gates;
        getParentModel().renderToBuffer(poseStack, buffer.getBuffer(RenderType.entityTranslucent(VEINS)), packedLight,
                OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, veins);

        // the aura, flowing upward round the body
        int c = EightGates.AURA_RGB[Math.min(8, gates)];
        float k = Math.min(1f, 0.4f + gates * 0.075f);
        getParentModel().copyPropertiesTo(shell);
        shell.setAllVisible(true);
        float t = entity.tickCount + partialTick;
        VertexConsumer vc = buffer.getBuffer(RenderType.energySwirl(AURA, (t * 0.003f) % 1f, (-t * (0.02f + gates * 0.004f)) % 1f));
        shell.renderToBuffer(poseStack, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                ((c >> 16) & 255) / 255f * k, ((c >> 8) & 255) / 255f * k, (c & 255) / 255f * k, 1f);
    }
}
