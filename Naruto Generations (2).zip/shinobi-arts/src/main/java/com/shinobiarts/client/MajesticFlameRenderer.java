package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.MajesticFlame;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Majestic Destroyer Flame: the jet from the mouth, then a towering front of billowing flame (stacked puffs from
 * flame_billow.png, always facing you, churning) rolling forward and spreading out, with a lower sea of fire left
 * burning behind it that shrinks and fades away.
 */
public class MajesticFlameRenderer extends EntityRenderer<MajesticFlame> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/flame_billow.png");

    public MajesticFlameRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(MajesticFlame entity, Frustum frustum, double x, double y, double z) {
        return frustum.isVisible(entity.getBoundingBoxForCulling());
    }

    @Override
    public void render(MajesticFlame e, float yaw, float partial, PoseStack ps, MultiBufferSource buffers, int light) {
        float age = e.tickCount + partial;
        float scale = e.getScale();
        int life = e.lifetime();
        if (age > life) return;
        Vec3 fwd = e.forward(), side = e.side();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(TEXTURE));
        float front = MajesticFlame.frontDistance(age, scale);
        float fade = Mth.clamp((life - age) / (MajesticFlame.LINGER * 0.8f), 0f, 1f);   // everything dies down at the end
        int seed = e.getId() * 7919;

        if (age < MajesticFlame.JET + 3) {
            // the jet: a narrow stream of fire from the mouth, thickening as it goes
            float jetFade = age < MajesticFlame.JET ? 1f : 1f - (age - MajesticFlame.JET) / 3f;
            float len = Math.min(6f, front);
            for (float t = 0.3f; t < len; t += 0.35f) {
                float s = 0.35f + t * 0.16f;
                Vec3 p = fwd.scale(t).add(0, 1.5 - t * 0.04, 0);
                puff(ps, vc, p, s, age * 9f + t * 40f, (int) (t * 3 + seed) & 3, jetFade);
            }
        }
        if (age < MajesticFlame.JET) return;

        // the sea of fire behind the front: lower, smaller, burning down
        for (float d = 2.5f; d < front - 3f; d += 2.6f) {
            float passed = age - MajesticFlame.ticksToReach(d);
            float burn = Mth.clamp(1f - passed / (MajesticFlame.LINGER + 25f), 0f, 1f) * fade;
            if (burn <= 0.02f) continue;
            float hw = MajesticFlame.halfWidth(d, scale);
            int cols = Math.max(1, (int) (hw * 2 / 2.4f));
            for (int j = 0; j <= cols; j++) {
                float l = -hw + 2 * hw * j / cols;
                int h = hash(seed, (int) (d * 10), j);
                float jx = ((h & 255) / 255f - 0.5f) * 1.6f, jz = (((h >> 8) & 255) / 255f - 0.5f) * 1.6f;
                float s = (1.6f + ((h >> 16) & 255) / 255f * 1.6f) * (0.45f + 0.55f * burn) * Math.min(1f, scale + 0.3f);
                Vec3 p = fwd.scale(d + jz).add(side.scale(l + jx)).add(0, s * 0.42f, 0);
                puff(ps, vc, p, s, age * 5f + h % 360, h & 3, burn);
            }
        }

        // the front: a wall of billows, the middle a little ahead of the ends, two rows deep
        float hw = MajesticFlame.halfWidth(front, scale);
        float height = MajesticFlame.height(front, scale);
        float burst = Mth.clamp((age - MajesticFlame.JET) / 4f, 0f, 1f);       // swells up out of the jet
        for (int row = 0; row < 2; row++) {
            float dist = front - row * 2.4f;
            if (dist < 1f) continue;
            float rhw = MajesticFlame.halfWidth(dist, scale), rh = MajesticFlame.height(dist, scale) * burst;
            int cols = Math.max(2, (int) (rhw * 2 / 1.7f));
            for (int j = 0; j <= cols; j++) {
                float u = -1f + 2f * j / cols;
                float l = u * rhw;
                float f = dist - 0.18f * rhw * u * u;
                float colH = rh * (1f - 0.35f * u * u);
                int layers = Math.max(1, (int) Math.ceil(colH / 2.0f));
                for (int k = 0; k < layers; k++) {
                    int h = hash(seed + row * 31, j, k);
                    float jx = ((h & 255) / 255f - 0.5f) * 1.2f, jy = (((h >> 8) & 255) / 255f - 0.5f) * 0.8f;
                    float s = (3.0f - k * 0.25f + ((h >> 16) & 255) / 255f * 1.2f) * Math.max(0.55f, Math.min(1f, height / 6f + 0.4f));
                    float y = 0.9f + k * colH / layers + jy;
                    float bob = Mth.sin(age * 0.5f + j * 1.7f + k) * 0.25f;
                    Vec3 p = fwd.scale(f + row * 0.0f).add(side.scale(l + jx)).add(0, y + bob, 0);
                    puff(ps, vc, p, s * (row == 0 ? 1f : 0.9f), age * (6f + (h & 7)) + h % 360, (h >> 4) & 3, fade);
                }
            }
        }
        super.render(e, yaw, partial, ps, buffers, light);
    }

    /** One flame puff at {@code p} (relative to the entity), {@code size} blocks across, turned to the camera. */
    private void puff(PoseStack ps, VertexConsumer vc, Vec3 p, float size, float spin, int variant, float alpha) {
        if (alpha <= 0.01f || size <= 0.01f) return;
        ps.pushPose();
        ps.translate(p.x, p.y, p.z);
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
        ps.mulPose(Axis.YP.rotationDegrees(180f));
        ps.mulPose(Axis.ZP.rotationDegrees(spin));
        ps.scale(size, size, size);
        PoseStack.Pose pose = ps.last();
        float u0 = (variant & 1) * 0.5f, v0 = (variant >> 1) * 0.5f;
        int a = Math.round(255 * Mth.clamp(alpha, 0f, 1f));
        vertex(vc, pose.pose(), pose.normal(), -0.5f, -0.5f, u0, v0 + 0.5f, a);
        vertex(vc, pose.pose(), pose.normal(), 0.5f, -0.5f, u0 + 0.5f, v0 + 0.5f, a);
        vertex(vc, pose.pose(), pose.normal(), 0.5f, 0.5f, u0 + 0.5f, v0, a);
        vertex(vc, pose.pose(), pose.normal(), -0.5f, 0.5f, u0, v0, a);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f pose, Matrix3f normal, float x, float y, float u, float v, int alpha) {
        vc.vertex(pose, x, y, 0f).color(255, 255, 255, alpha).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }

    private static int hash(int a, int b, int c) {
        int h = a * 73856093 ^ b * 19349663 ^ c * 83492791;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return h & 0x7fffffff;
    }

    @Override
    public ResourceLocation getTextureLocation(MajesticFlame entity) {
        return TEXTURE;
    }
}
