package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Jutsu projectiles: the Great Fireball (textures/entity/jutsu/fireball.png, as big as its charge) and the Water
 * Bullet (water_ball.png) are glowing sprites that always face the camera, spinning slowly; the Water Dragon is a
 * whole dragon of water (WaterDragonRender). Every jutsu also keeps its particle trail; the others are drawn with
 * particles only.
 */
public class JutsuProjectileRenderer extends EntityRenderer<JutsuProjectile> {
    private static final ResourceLocation FIREBALL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/fireball.png");
    private static final ResourceLocation WATER_BALL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/water_ball.png");

    public JutsuProjectileRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    protected int getBlockLightLevel(JutsuProjectile entity, BlockPos pos) {
        return 15;
    }

    @Override
    public void render(JutsuProjectile entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        ResourceLocation texture;
        float size, spin;
        switch (entity.getKind()) {
            case FIRE_BALL -> {
                texture = FIREBALL;
                size = 1.3f * entity.getScale();
                spin = 4f;
            }
            case WATER_BULLET -> {
                texture = WATER_BALL;
                size = 0.5f;
                spin = 12f;
            }
            case WATER_DRAGON -> {
                WaterDragonRender.render(entity, partialTick, poseStack, buffer, packedLight);
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
            default -> {
                super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
                return;
            }
        }
        poseStack.pushPose();
        poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180f));
        poseStack.mulPose(Axis.ZP.rotationDegrees((entity.tickCount + partialTick) * spin));
        poseStack.scale(size, size, size);
        PoseStack.Pose pose = poseStack.last();
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucentEmissive(texture));
        vertex(consumer, pose.pose(), pose.normal(), -0.5f, -0.5f, 0f, 1f);
        vertex(consumer, pose.pose(), pose.normal(), 0.5f, -0.5f, 1f, 1f);
        vertex(consumer, pose.pose(), pose.normal(), 0.5f, 0.5f, 1f, 0f);
        vertex(consumer, pose.pose(), pose.normal(), -0.5f, 0.5f, 0f, 0f);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f pose, Matrix3f normal, float x, float y, float u, float v) {
        consumer.vertex(pose, x, y, 0f).color(255, 255, 255, 255).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(JutsuProjectile entity) {
        return FIREBALL;
    }
}
