package com.shinobiarts.jutsu;

import com.shinobiarts.Config;

/**
 * Hold-to-charge casting. Holding right-click with a release charges its selected jutsu (like drawing a bow);
 * letting go casts it. A quick tap casts at {@code chargeMinPower} of its damage and a full charge at
 * {@code chargeMaxPower}; how long a full charge takes is {@code chargeSeconds}. All three are set per jutsu. Only jutsu that deal damage
 * charge: utility jutsu (Substitution, armors, walls, healing...) still go off the moment you right-click.
 * Shared by the server (the cast) and the client (the charge counter on screen).
 */
public final class JutsuCharge {
    private JutsuCharge() {}

    public static boolean chargeable(Jutsu jutsu) {
        return Config.b(Config.CHARGE_ENABLED) && Jutsus.upgradeable(jutsu);
    }

    /** Ticks for a full charge ("chargeSeconds" in the jutsu's section of Jutsus.toml: 0.5 s for D up to 2.5 s for S). */
    public static int fullChargeTicks(Jutsu jutsu) {
        Config.JutsuValues v = Config.jutsu(jutsu.id());
        double seconds = v == null ? 1.0 : Config.d(v.chargeSeconds());
        return Math.max(1, (int) Math.round(seconds * 20.0));
    }

    /** 0..1: how charged the jutsu is after holding for {@code ticks}. */
    public static float fraction(Jutsu jutsu, int ticks) {
        return Math.min(1f, Math.max(0f, ticks / (float) fullChargeTicks(jutsu)));
    }

    /** Damage multiplier for a charge: chargeMinPower at a tap, chargeMaxPower at full. */
    public static float power(Jutsu jutsu, int ticks) {
        Config.JutsuValues v = Config.jutsu(jutsu.id());
        float min = v == null ? 0.6f : Config.f(v.chargeMinPower());
        float max = Math.max(min, v == null ? 1.5f : Config.f(v.chargeMaxPower()));
        return min + (max - min) * fraction(jutsu, ticks);
    }
}
