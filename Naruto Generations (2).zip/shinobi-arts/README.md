# Naruto Generations — a ninja mod for Minecraft Forge 1.20.1

Chakra, releases and jutsu, levels and stats, Ryo, and ninja tools.

## Building the jar

**With GitHub (no Java needed):** upload `Naruto Generations.zip` (still zipped) to your repository, after
deleting the old zip (the workflow builds every zip it finds). The "Build mod jar" workflow runs on its own. When it's green, download **shinobiarts-jar**,
unzip it, and put `Naruto Generations-1.2.0.jar` in your profile's `mods` folder (remove any older copy of the mod
first: two copies of the mod crash the game).

**On your PC:** install JDK 17, open a terminal in this folder and run `gradlew build`
(`./gradlew build` on Mac/Linux). The jar appears in `build/libs/`.

## What's new in 1.2.0

- **Water Prison**: a swirling sphere of water closes around the target and drags it to your outstretched hand. Inside
  it can't move or act, its air runs out and it takes damage every second. You can turn but not walk away, or the
  prison bursts. It lasts `waterPrisonSeconds` (6 s) in `Jutsus.toml`. Very large creatures are caught where they stand.
- **Water Dragon**: water surges up out of the ground in front of you into a great translucent dragon (horned head,
  open jaws, glowing eyes, a long body that follows its path), which rises, then curves over and charges at what you
  aimed at.
- **Majestic Destroyer Flame** (Fire, S rank, new): charge it (the hand sign), and a jet of fire from your mouth bursts
  into a towering wall of flame that rolls 32 blocks forward, spreading up to 30 wide and 8 high. It burns everything
  it passes and leaves a sea of fire behind it. A tap makes a smaller wave. Scroll: blank scroll + 2 blaze rods + fire
  charge + diamond.
- **Releases are held out of sight**: the emblem of the release you hold (kekkei genkai releases too) sits on the
  underside of your hand instead of being carried like an item.
- **Config split into files**, kept together in `saves/<world>/serverconfig/Naruto Generations/`: `Jutsus.toml`,
  `Weapons.toml`, `Food.toml`, `Stats.toml`, `Spawn weights and chances.toml` and `General.toml`. **Every jutsu has its
  own section** in `Jutsus.toml` (`[jutsu.fireball]`...) with its chakra cost, damage multiplier, cooldown and charge.
  The old `shinobiarts-server.toml` isn't read any more: copy any values you changed into the new files.
- **Jutsu cost more chakra**: by rank, D 18%, C 22%, B 27%, A 33%, S 40% of max chakra (was 15% for all).
- **Chakra Control**: climb a wall just by walking into it while looking at it, **walk upside down on ceilings**
  (jump or climb into one, sneak to drop off; others see you hanging upside down), and **Ninja Jump from the water**.
- **Stats menu (J)**: hold a **+** to keep adding points; new **Quests** tab (your own village's quest board) and
  **Credits** tab (edit the lines in `General.toml` → `[credits]`).
- **Eight Gates**: an aura in each gate's colour around the body, flushed skin and veins from the Gate of Life on,
  much more speed, strength and damage resistance, and the **Gate of Death kills you** when it closes
  ("<player> opened the 8th gate and withered away"; `gateOfDeathKills` in the config).
- **Eye key (V)**: tap once for the Sharingan at your highest tomoe, **double-tap for the Mangekyou, triple-tap for
  the Eternal Mangekyou**. The eyes sit closer together on the face.
- **Kekkei genkai for everyone**: having one (from your clan or awakened) gives its **whole skillset** (the release
  and all its jutsu; the Byakugan brings Palm Rotation). **DNA** of every kekkei genkai (Wood, Ice, Magnet, Bone,
  Sealing, Sharingan, Byakugan) drops from the mobs you list in `Spawn weights and chances.toml` and from defeated
  players; reading a kekkei genkai jutsu scroll awakens it too.
- **DNA for the releases too**: Fire, Water, Wind, Lightning, Earth and Yin Yang DNA unlock that chakra nature (like a
  nature scroll). Every DNA is a corked vial with the DNA symbol, its liquid in the colour of what it holds (Fire red,
  Water blue, Wind green, Lightning yellow, Earth brown, Yin Yang purple, Wood dark green, Ice light blue, Magnet
  grey, Bone ivory, Sealing pink, Sharingan crimson, Byakugan lavender).
- **Susanoo**: builds itself up over 2.5 s (bones, then body, then armor); health 1,000 / 1,800 / 4,000 / 7,000 /
  11,000; you ride in the **chest** of the Humanoid and Armored stages; the Armored stage's shield sits in front of
  its hand.
- **Shadow Possession**: a black shadow streaks along the ground to the target, which then copies every step, jump,
  turn and swing you make. New **Multi Shadow Clone Jutsu** (A rank, 10 clones; crafted from a Shadow Clone scroll,
  2 lapis and a diamond).
- **Kusanagi**: each Chidori Flow stun costs 10% of your chakra and then recharges for 15 s.
- **Death messages name the jutsu** ("Steve was killed by Alex's Chidori").
- **Clans**: claim **any** clan you rolled (`/clanroll claim <clan>`, or click it in chat), and every clan's bonuses
  are now potion effects (see the table below).
- **Kage** can post one quest every 60 minutes (`kageQuestCooldownMinutes`).
- **HUD**: the "hold a release" hint stays on the scroll, Ryo is shortened (1.2k, 15k, 250k, 1.5M), and an XP bar
  sits before your level.
- **Creative tabs**: releases, then nature scrolls, then jutsu scrolls grouped by release; the swords of the Seven
  Ninja Swordsmen have their own tab. The Gunbai and Kabutowari are bigger.

## Controls (rebind in Options → Controls → Naruto Generations)

| Key | Action |
|---|---|
| **Right-click** | Cast the selected jutsu of the release you're holding |
| **G / H** | Move the jutsu arrow right / left |
| **J** | Stats menu |
| **Z** (hold) | Charge chakra (standing still also gathers Senjutsu) |
| **B** | Toggle Sage Mode |
| **V** | Switch your eyes on/off (Sharingan, Byakugan; cycles if you own both). Double-tap: Mangekyou, triple-tap: Eternal Mangekyou |
| **R / Y / U** | Jutsu 1 / Jutsu 2 / Jutsu 3: your Sharingan's eye techniques (see Sharingan below; Kamui is held on Y) |
| **K** | Toggle Substitution: while it's on, attacks hit a log instead of you (needs the Substitution Jutsu) |
| **N** | Toggle Chakra Control: walk up walls (walk into them looking at them), hang from ceilings, walk on water |
| **I** | Eight Inner Gates: open the next gate (Shift + I closes them all) |
| **O** | Susanoo (Mangekyou on): summon it, press again to grow it a stage (Shift + O releases it) |
| **Shift + Space** | Ninja Jump from the ground, or from the water with Chakra Control on (15 chakra, no cooldown) |

Your health bar sits above the hotbar where the hearts were. The panel to the left of the hotbar shows
Ryo, level, the chakra figure with the soft chakra and Senjutsu bars, and the jutsu slots of the release you're holding.
Every time you join a world or server, a clickable Discord invite appears in chat.

## How it works

### Clans
There are **30 clans**. New players start without one and roll it with **`/clanroll`**:
- Each `/clanroll` rolls a new clan (replacing the last one). Every player gets **2 rolls** (`clanRolls` in the config).
- **`/clanroll claim`** locks the current clan in for good. After that, `/clanroll` says
  *"Sorry, you already claimed your clan."*
- With no rolls left, `/clanroll` says *"You have used all of your rerolls!"* and the last rolled clan stays.
- Rolling away from Uchiha takes back the Sharingan you got with it; clans with a fixed nature (e.g. Uchiha = Fire)
  set your affinity unless you've already revealed it with Chakra Paper.
- Players from older versions keep the clan they had, already claimed. `/shinobi clanroll <player> reset` gives
  someone their rolls back.

The clan's bonuses are passive and always on. Hover over your clan in the stats menu (J), or type `/clan`, to see
them. `/clan list` shows every clan and its chance, and `/clan info <clan>` shows any clan's bonuses. Rare and
Mythic rolls are announced to the whole server.

| Rarity | Chance (each) | Clans |
|---|---|---|
| Mythic | 1 in 100,000 per roll | Ōtsutsuki |
| Rare | 1 in 138 per roll | Uchiha, Senju, Uzumaki |
| Uncommon | 1 in 46 per roll | Hyūga, Kurama, Kaguya, Yuki, Kazekage, Chinoike, Hagoromo |
| Common | 1 in 23 per roll | Nara, Akimichi, Yamanaka, Aburame, Inuzuka, Sarutobi, Hatake, Shimura, Fūma, Hōzuki, Hoshigaki, Karatachi, Shirogane, Yotsuki, Kamizuru, Iburi, Tsuchigumo, Funato, Taketori |

| Clan | Bonuses |
|---|---|
| **Ōtsutsuki** | Byakugan, Strength III, Speed II, Resistance II, Regeneration II, Health Boost III, Slow Falling I, Chakra Regeneration 1.5x |
| **Uchiha** | Fire affinity, Sharingan at birth, Speed II, Fire Resistance I, Night Vision I (while the Sharingan is on) |
| **Senju** | Earth affinity, Health Boost II, Regeneration I, Resistance I, Chakra Regeneration 1.75x (Wood Release blood) |
| **Uzumaki** | Health Boost III, Regeneration II, Resistance I, Fire Resistance I, Chakra Regeneration 2x, double shadow clones |
| Hyūga | Byakugan, Speed I, Jump Boost II, Resistance I, Night Vision I (while the Byakugan is on), Palm Rotation |
| Kurama | Night Vision I, Resistance I, Chakra Regeneration 1.25x |
| Kaguya | Strength II, Resistance II, Health Boost II |
| Yuki | Water affinity, Fire Resistance I, Resistance I, Water Breathing I |
| Kazekage | Earth affinity, Resistance II, Slow Falling I, Health Boost II |
| Chinoike | Night Vision I, Strength I, Resistance I |
| Hagoromo | Health Boost II, Regeneration II, Resistance II, Chakra Regeneration 1.5x |
| Nara | Night Vision I, Speed I, Resistance I, Shadow Possession |
| Akimichi | Strength II, Resistance II, Health Boost II, Slowness I |
| Yamanaka | Speed I, Night Vision I, Resistance I |
| Aburame | Resistance I, Night Vision I, Poison Immunity, Speed I |
| Inuzuka | Speed II, Jump Boost II, Strength I, Night Vision I |
| Sarutobi | Fire affinity, Strength I, Fire Resistance I, Resistance I |
| Hatake | Lightning affinity, Speed III, Strength I, Resistance I, Permanent Saturation (never hungry) |
| Shimura | Wind affinity, Speed I, Resistance I, Fire Resistance I |
| Fūma | Speed II, Jump Boost II, Strength I |
| Hōzuki | Water affinity, Water Breathing I, Dolphin's Grace II, Speed I |
| Hoshigaki | Water affinity, Water Breathing I, Dolphin's Grace III, Strength II, Resistance I |
| Karatachi | Water affinity, Water Breathing I, Speed I, Resistance I |
| Shirogane | Speed I, Night Vision I, Resistance I |
| Yotsuki | Lightning affinity, Speed II, Strength II, Jump Boost II, Resistance I |
| Kamizuru | Speed I, Night Vision I, Poison Immunity |
| Iburi | Speed II, Slow Falling I, Fire Resistance I |
| Tsuchigumo | Strength II, Resistance II, Health Boost II |
| Funato | Water affinity, Water Breathing I, Dolphin's Grace II, Speed I |
| Taketori | Strength II, Resistance I, Speed I |

The effects are kept topped up without particles. Health Boost is given as permanent max health (4 per level), so it
never resets your hearts. The chances are in `Spawn weights and chances.toml` (a weight per tier, and `mythicChance` for
Ōtsutsuki); `/shinobi clan <player> <clan>` sets one directly.

### Releases and jutsu
- There are 7 releases: Fire Release, Water Release, Wind Release, Lightning Release, Earth Release, Yin Yang Release,
  and Ninjutsu Release, plus 5 **clan releases** that only one clan can use (see *Clan releases* below).
  **Hold one** (either hand) to equip it: its octagon emblem sits small and flat on the underside of your hand (only
  seen from below; in first person you just see your bare hand), and the HUD shows its jutsu slots.
- New players get the **Ninjutsu Release**, empty at first.
- **Chakra Paper** reveals your nature affinity and gives you that release. **Training Scrolls**
  unlock more natures, including Yin Yang.
- **Jutsu scrolls** teach a jutsu permanently and add it to its release's slots. Shadow Clone,
  Rasengan, Body Flicker and clan jutsu go in Ninjutsu. Substitution has its own key instead (see below).
- Every jutsu has a **rank from the show**, D (weakest) to S (strongest). The rank is on the scroll's tooltip
  and colors its name, and the creative tab lists scrolls from D to S. D, C and B rank can be learned at any level;
  only A and S rank need a minimum level (configurable in `jutsuRanks`):

| Rank | Level | Jutsu |
|---|---|---|
| D | any | Substitution, Body Flicker, Hell Viewing, Water Bullet |
| C | any | Great Fireball, Phoenix Flower, Water Prison, Gale Palm, Great Breakthrough, Mind Fog, Shadow Possession |
| B | any | Great Fire Annihilation, Water Dragon, Vacuum Blade, Earth Wall, Rock Armor, Rising Spikes, Shadow Clone |
| A | 90 (Chunin) | Lightning Armor, Chidori, Thunder Strike, Mystical Palm, Rasengan, Eight Trigrams Palm Rotation |
| S | 175 (Jonin) | Majestic Destroyer Flame, Vitality Surge, Rasenshuriken |

Clan release jutsu have ranks too (C, B, and A or S; see *Clan releases*).

- **Hold right-click to charge** a jutsu that deals damage, and let go to cast it. A counter under the crosshair shows
  the charge (0-100%, then a pulsing gold **MAX**) and the damage it will do: a quick tap casts at x0.6, a full charge at
  x1.5. A full charge takes 0.5 s for D rank up to 2.5 s for S rank; chakra gathers around your hands and a chime
  plays when it's full. The counter turns red if the jutsu is still cooling down or you're short on chakra.
  Utility jutsu (Substitution, Body Flicker, armors, walls, healing, Shadow Clone...) still cast the moment you click.
  Everything is in the `charging` config section (set `enabled = false` to cast every jutsu on click).
- **Rasengan**: two shadow clones (wearing your skin) pop out of smoke on either side of you and cup their hands round
  your palm while the ball grows and spins faster; after about 1.5 s they vanish and you hold it on your fist (about
  a block across, everyone can see it) until your next punch sets it off. It can't hit anything while it's forming.
  It's drawn from OPREXT's Partical Rasengan model.
- **Rising Spikes** bursts the Earth Flow Spike Cluster out of the ground where you look: one big cluster in the middle
  and four smaller ones round it, which stand for 2 seconds and sink back. The damage and launch are the same as before.
- **Great Fireball** grows with its charge: a quick tap throws a small fireball, a full charge a huge one with a
  bigger blast (about 2 to 5.5 blocks). It and the **Water Bullet** are drawn as glowing balls, and **Lightning
  Armor** wraps you in a crackling blue shell that everyone can see.
- **Substitution** is a toggle: once you've learned it from its scroll, press **K** to switch it on (the HUD shows
  *Substitution*, grey while it's cooling down). While it's on, a hit from a creature or player misses you: you jump
  4 blocks back (away from the attacker) and 2 up, and leave 2 logs where you stood that vanish after 10 seconds.
  You take no fall damage from the jump. Each swap costs the jutsu's chakra (15% of max) and starts its 8 s cooldown;
  without enough chakra, or while it cools down, hits land normally. Press K again to switch it off.
  (`substitutionBlocksBack`, `substitutionBlocksUp`, `substitutionLogSeconds` in the `jutsuTuning` config section.)
- **Chakra Control** (press **N**; anyone can use it): walk into a tree or wall **while looking at it** (or up) to walk
  up it; sneak to cling in place. Looking away while pushing against it, you slide down slowly and take no fall
  damage; step away from the wall to drop. Jump or climb into a **ceiling** to hang from it upside down and walk around;
  sneak to drop off. You also **walk on water** (sneak to sink in and swim) and can **Ninja Jump** from the water. It
  drains 0.5 chakra a second while you're climbing, on a ceiling or standing on water and stops working below 1 chakra
  (`chakraControl` in `Jutsus.toml`).
- **Jutsu cost a share of your max chakra by rank**: D 18%, C 22%, B 27%, A 33%, S 40% (more Ninjutsu points mean
  more casts). Each jutsu's cost, damage, cooldown and charge are in its own section of `Jutsus.toml`, and
  `chakraCostMultiplier`, `damageMultiplier` and `cooldownMultiplier` scale them all.
- Jutsu scrolls are colored by the release they go into, training scrolls by their nature: Fire red, Water blue,
  Wind teal, Lightning yellow, Earth brown, Yin Yang black, Ninjutsu (and the Nara and Hyuga clan jutsu) purple,
  Wood green, Ice pale blue, Magnet iron grey, Bone ivory, Sealing rose. Their inventory pictures are rendered from the
  3D scrolls.

### Clan releases
Five clans have a release of their own (kekkei genkai), shown as an octagon emblem with its kanji like the others:

| Release | Clan | Kanji |
|---|---|---|
| Wood Release | Senju | 木 |
| Ice Release | Yuki | 氷 |
| Magnet Release | Kazekage | 磁 |
| Bone Release (Dead Bone Pulse) | Kaguya | 骨 |
| Sealing Release | Uzumaki | 封 |

- **When your clan is yours for good** (`/clanroll claim`) you get the release **and all three of its jutsu** (a chat
  message announces it). An admin moving you to another of these clans gives you that clan's release instead.
- **Anyone can gain a kekkei genkai**: right-click its **DNA** (dropped by the mobs listed in `Spawn weights and
  chances.toml` and by defeated players) or read one of its jutsu scrolls. You get the release and all of its jutsu
  straight away. Sharingan and Byakugan DNA give the eyes (the Byakugan also brings Palm Rotation).
- Nature DNA (Fire, Water, Wind, Lightning, Earth, Yin Yang) drops the same way and unlocks that release once your
  affinity is revealed. Mob drops pick any of the 13 DNA at random; a defeated player drops one of their own natures or
  kekkei genkai.
- Holding another clan's release does nothing (its tooltip says whose it is), and the Sharingan can't copy these jutsu.
- Blocks they make (wood, ice, iron sand, bone spikes) go only into empty space (plants too with jutsu griefing on),
  never into a creature, break by themselves and drop nothing; you can break out of them.

| Release | Jutsu | Rank | What it does | Cooldown |
|---|---|---|---|---|
| Wood | **Wood Binding** (given) | C | Roots race to the creature you look at (24 blocks) and coil round it: 6 damage and held fast for 4 s (no moving, attacking or jutsu) | 10 s |
| Wood | **Wood Dome** | B | A dome of wood (radius 3) grows up around you and keeps out attacks and projectiles for 10 s | 30 s |
| Wood | **Deep Forest Emergence** | S | A forest bursts out of the ground where you look (9 x 9): the rising trees deal 10 damage and throw everything up, then for 20 s the roots deal 1.5 damage a second, slow and drag in whoever stays | 60 s |
| Ice | **Ice Needles** (given) | C | A fan of 8 ice needles, 2 damage each (every needle counts), each slows and chills | 2 s |
| Ice | **Ice Prison** | B | 5 damage and the target freezes solid inside ice for 3 s | 12 s |
| Ice | **Demonic Ice Mirrors** | A | A ring of 12 ice mirrors around the target; for 6 s needles fly from the mirrors (15 hits of 1.5) while it stays inside | 30 s |
| Magnet | **Iron Sand Drizzle** (given) | C | Iron sand rains on where you look (5 blocks wide): 8 volleys of 1.5 damage | 3 s |
| Magnet | **Iron Sand Coffin** | B | Iron sand swallows the target, holds it, and crushes it shut 1.5 s later for 16 damage | 12 s |
| Magnet | **Iron Sand World Method** | A | A mass of iron sand forms in front of you and bursts into spikes in every direction: 16 damage to everything within 8 blocks of it, thrown back | 20 s |
| Bone | **Finger Bone Bullets** (given) | C | Five bone bullets in a row (3.5 damage each) wherever you're aiming | 2 s |
| Bone | **Dance of the Willow** | B | Bones jut out like blades and armor: Strength II and Resistance I for 20 s | 30 s |
| Bone | **Dance of the Seedling Fern** | A | Huge bone spikes erupt around you in 4 waves out to 9 blocks: 14 damage and thrown up (once each); the spikes stay 8 s | 30 s |
| Sealing | **Barrier** (given) | C | A sealing barrier around you for 8 s: arrows, thrown weapons and projectile jutsu are stopped at its edge, creatures that come at you are pushed back out | 20 s |
| Sealing | **Adamantine Sealing Chains** | B | Chakra chains bind the target for 4 s (3 damage); a ninja loses 30% of their chakra, a creature is weakened | 15 s |
| Sealing | **Five Elements Seal** | A | Up close (5 blocks): seals the target's chakra for 10 s, no jutsu, eye techniques or Eight Gates; a ninja's eyes switch off and open gates close | 45 s |

Damage numbers are before the damage multiplier, upgrades and charging. Deep Forest, the Ice Needles and Mirrors, all
three Magnet jutsu, the Finger Bone Bullets and the Seedling Fern charge and can be upgraded with Jutsu Points.

### Sharingan
- **Anyone can own the Sharingan.** Uchiha are born with a 1-tomoe Sharingan; anyone else gets one by taking it.
- **Evolution, one stage at a time:** 1 tomoe → 2 tomoe at level 30 → 3 tomoe at level 60 → **Mangekyou** once
  you're level 100 with 3 tomoe *and* survive a near-death experience (health at or below 5% of max).
- Press **V** to switch it on (it drains chakra). Your face shows the eyes of your stage to everyone, and the
  eyes flash across your screen when you switch them on or they evolve.
- Stronger stages dodge more hits (12% / 18% / 25% / 32%, raised by Genjutsu, max 50%) and copy jutsu from
  farther away.
- **Mangekyou patterns:** an awakened Mangekyou takes **Itachi's, Sasuke's or Obito's** pattern at random. It shows on
  your face, in the screen flash and in the HUD's eye slot, and it decides your eye techniques: Itachi has Amaterasu
  and Tsukuyomi, Sasuke has Amaterasu and Blaze Release, Obito has Kamui. Implanting a
  stolen Mangekyou eye into your own Mangekyou awakens the **Eternal Mangekyou**.
- **Eye techniques** (Jutsu 1/2/3 keys, R/Y/U by default; your Sharingan must be on). They show next to your armor
  above the HUD scroll, with their key and cooldown. **Every eye's tooltip lists its techniques and the keys you have
  bound for them** (the eyes in your dojutsu slot, stolen Sharingan Eyes, and the Sharingan item):

| Key | Eyes | Technique |
|---|---|---|
| Jutsu 1 | Itachi, Sasuke, Eternal | **Amaterasu**: black flames on the spot you look at (and on the creature there). They burn anything that walks in, never spread or burn blocks, can't be put out with water, and die out after 5 minutes. **Sneak with your Mangekyou on** to put out every black flame within 10 blocks. Strains your eyes (blindness + 1 heart), except the Eternal Mangekyou. 25% chakra, 30 s cooldown |
| Jutsu 2 (hold) | Obito | **Kamui**: while you hold the key you're intangible: you **fly through blocks**, and attacks, arrows and jutsu pass through you (you can't hurt anyone either). Let go to come back; if you're inside a wall, you come out at the nearest open spot. Lasts up to 15 s. 20% chakra + 3 per second, 10 s cooldown after it ends |
| Sneak + Jutsu 2 | Obito | **Kamui snap**: tears at the creature you look at for **50% of its max health**, ignoring armor (bosses at most 20). 30% chakra, 30 s cooldown |
| Jutsu 2 | Itachi | **Tsukuyomi**: the creature or player you look at (20 blocks) is frozen for 4 seconds: they can't move, attack or use jutsu, players lose 40% of their chakra and their screen turns red and black. When it ends they take **25% of their max health** at once, ignoring armor (bosses at most 20), then nausea and slowness. A victim with their Sharingan on is held half as long. Strains your eyes. 30% chakra, 40 s cooldown |
| Jutsu 2 | Sasuke, Eternal | **Blaze Release**: spikes of black flame burst out of the ground in a line 15 blocks toward where you look; everything they hit takes 9 damage and catches Amaterasu. Strains your eyes (not the Eternal). 25% chakra, 20 s cooldown |
| Sneak + Jutsu 2 | Sasuke, Eternal | **Flame Wall**: a 7-block wall of black flames 3 blocks ahead for 15 seconds. Anything walking into it burns with Amaterasu and is thrown back; arrows and jutsu thrown through it burn up. 25% chakra, 30 s cooldown |
| Jutsu 3 | every Sharingan | **Genjutsu**: traps the creature you look at in an illusion (darkness, nausea and slowness for players; mobs lose track of you). Longer and farther with each stage and with Genjutsu; the Mangekyou also roots them in place. 10% chakra, 20 s cooldown |

  All numbers are in the `eyeTechniques` config section. Amaterasu used to be a jutsu scroll: players who learned it
  get their Jutsu Points back, and old Amaterasu scrolls turn into Blank Scrolls.
- **Byakugan techniques** (Hyūga and Ōtsutsuki, with the Byakugan on; same keys):

| Key | Technique |
|---|---|
| Jutsu 1 | **Eight Trigrams 64 Palms**: dash to the creature or player within 6 blocks and strike 8 times (24 damage in all). Their **chakra points are sealed** for 8 seconds: no jutsu, eye techniques or Susanoo. Players also lose half their chakra; creatures are slowed and weakened. 20% chakra, 25 s cooldown |
| Jutsu 2 | **Air Palm**: a blast of air down your line of sight (20 blocks): 10 damage and a big knockback. 8% chakra, 5 s cooldown |
| Jutsu 3 | **All-Seeing Eye**: for 20 seconds everything living within 60 blocks glows through walls (invisible players too), and the top of your screen warns you when a player or monster is right behind you. 10% chakra, 40 s cooldown |

  The Byakugan now shows on your face (with the veins around the eyes) and flashes across your screen when you
  switch it on, like the Sharingan.
- **Taking eyes:** defeating a Sharingan user in PvP (a kill that gives PvP rewards) gives you a **Sharingan Eye**
  (a Mangekyou eye keeps its pattern). Right-click it to implant it: you get its stage, limited by your level
  (a Mangekyou eye needs level 100). Players who weren't born Uchiha lose their Sharingan when it's taken; Uchiha
  keep their bloodline eyes.
- **Dojutsu slot:** your inventory has an extra slot just above the off-hand, marked with a grey Sharingan (the way
  empty armor slots show a grey helmet). **Switching your eyes on (V) puts them in the slot**: your Sharingan at its
  stage and Mangekyou pattern, or the Byakugan. They're locked there, and **switching them off takes them out again**
  (so does running out of chakra or dying).
  While your eyes are off, the slot can hold the **Sharingan** item (2 Eyes of Ender and a block of redstone, in a
  row; right-click it to put it on): cosmetic eyes, 3 tomoe on your face, and your helmet slot stays free for real
  armor. Switching your own eyes on moves it back into your inventory. It drops on death like armor. Sharingans worn
  as helmets before this update move into the slot on their own.

### Susanoo
With the **Mangekyou Sharingan switched on**, press **O** to summon a Susanoo around you. Press O again to grow it
into the next stage, as far as your level allows; **Shift + O** releases it.

| Stage | Look | Level | Health | Takes for you | Left-click combo (empty hand) | Right-click special (empty hand) |
|---|---|---|---|---|---|---|
| 1 Ribcage | spine and ribs over chakra flames, 4 blocks | 100 | 300 | 70% | none (shoves attackers back) | none |
| 2 Skeletal | skull and clawed arms, 7 blocks | 125 | 600 | 85% | 10 / 10 / 15, reach 5 | Ground slam: 18 within 4 blocks, launches up (6 s) |
| 3 Humanoid | chakra muscle, fierce face, sword, 10 blocks | 150 | 1,200 | 100% | 16 / 16 / 24, reach 7 | 3 homing magatama, 12 each (8 s) |
| 4 Armored | samurai armour, horned helmet, shield, 14 blocks | 200 | 2,500 | 100% | 22 / 22 / 33, reach 8 | Chakra slash wave: 35, 30 blocks, goes through everything (10 s) |
| 5 Perfect | a winged giant with a greatsword, 24 blocks | 250 + Eternal Mangekyou | 5,000 | 100% | 40 / 40 / 60, 16 blocks wide | Giant slash wave: 70, 50 blocks, 16 wide (15 s) |

- **It takes the hits meant for you** on its own health bar (top of the screen). You take no knockback and no fall
  damage while it stands. Health grows with your max chakra (half as fast). Others can also hit it directly.
- **Shift blocks**: hits from the front do 60% less; the Armored stage's shield blocks 90%; the Perfect stage's wings
  wrap round you and block 75% from every side. You can't swing while blocking.
- It **heals** 2% a second once it hasn't been hit for 5 seconds (that costs a little chakra). At 0 it **shatters**
  and you can't summon it again for 30 seconds.
- **Chakra**: summoning or growing costs 10/15/20/25/35% of your max chakra, and it uses 1/1.5/2/2.5/3.5% every
  second. When you run out it fades. Specials cost 5-10%.
- **Counters**: Amaterasu sets it alight (4% of its health a second instead of burning you); the Kamui snap and
  Tsukuyomi go straight through it. Sealed chakra (Five Elements Seal, 64 Palms) or your eyes switching off end it,
  and the Eight Gates can't be opened inside one (or the other way round).
- The combo hits everything in an arc in front; the third swing hits harder and throws them back. Damage gets your
  Kenjutsu bonus and the damage multiplier.
- **The Perfect Susanoo carries you in its forehead crystal**, 20 blocks up. Fly as usual (space up, Shift down) and
  it goes with you: it walks when it's on the ground (its feet never sink into it) and beats its wings in the air.
  It turns where you look. In first person its head isn't drawn and the screen edges take the crystal's tint;
  others see you through a glassy head. Releasing it sets you back on the ground.
- **Colours**: `/susanoo color <part> <colour>` with a preset (purple, blue, light_blue, red, green, yellow, orange,
  white, cyan, pink) or any `#RRGGBB`. Parts: `body`, `armor`, `weapon`, `eyes`, `chakra` (the rim light and glow),
  `aura`, or `all` with a preset. `/susanoo colors` shows yours, `/susanoo color reset` goes back to purple.
- Your own arrows, jutsu and crosshair go straight through your Susanoo.
- Everything is in the `susanoo` config section (levels, health, how much it takes, chakra, combo and special damage,
  cooldowns, block strength, Amaterasu burn). Specials can break blocks if you turn `specialsBreakBlocks` on.
- The models are smooth meshes made by `tools/make_susanoo.py` (from `tools/susanoo/`): see-through bodies tinted in
  your colours, with a rim of chakra light and a soft glow around the edges. Its swings, special and blocking poses
  are keyframes in `tools/susanoo/anims.py`.

### Eight Inner Gates
The taijutsu path for ninja without special eyes. Press **I** to open the next gate, one at a time; **Shift + I**
closes them all. Each gate needs **10 more Taijutsu points** (the eighth needs 80).
- Every open gate adds **+8% speed, +10% attack speed, +2 bare-hand damage** and higher jumps.
- **Gate 2 (Healing)** heals 4 hearts when it opens.
- **From gate 3 on, the gates cost health every second**: 0.5, 1, 1.5, 2 and 3 for gates 3-7. They never kill you:
  at half a heart they close themselves. Closing gate 5 or higher leaves your muscles sore (weakness and slowness
  for a few seconds).
- Your aura steams **blue**, **green from gate 6**, and **red at gate 8**. The HUD shows which gate is open.
- **Gate 8, the Gate of Death:** double bare-hand damage and more speed for 20 seconds. Press **I** again for
  **Night Guy**: a dash of up to 16 blocks that hits everything in its path for 100 damage. When the gate closes
  you're left at **one heart**, badly weakened for a minute, and **the gates stay locked for 10 minutes**.
- Everything is in the `eightGates` config section.

### Forehead protectors
Craft one from an **iron ingot and 2 wool** (any colour) and wear it in the helmet slot (1 armor). The metal plate
(from Calfan's Naruto Headbands model) sits on the cloth and shows **the village of whoever wears it**: Hidden Leaf,
Sand, Mist and Cloud have their own symbols, and so do villages with the ids `rain` and `sound` if you add them.
Without a village it's the **scratched Leaf plate**, like a rogue ninja's. Stone, other villages and a protector
nobody has worn yet show **忍** (shinobi). Dye the band like leather armor (navy blue by default). To give a village
its own plate, add `assets/shinobiarts/textures/entity/headband/plate_<village id>.png` (512 x 173, transparent
outside the plate) in a resource pack.

### Advancements
Open the advancements screen (**L**) for two new tabs:
- **Naruto Generations:** one advancement per release (Fire Release, Water Release...) with every jutsu of that
  release under it (the clan releases stay hidden unless they're yours), plus the Sharingan's stages (Sharingan, Two Tomoe, Three Tomoe, Mangekyou, each Mangekyou
  pattern, Eternal Mangekyou) and the Byakugan. You get one each time you learn a jutsu, unlock a release or awaken
  an eye; S-rank jutsu and the Mangekyou are challenges.
- **Shinobi Clans:** one hidden advancement per clan, given once your clan is yours for good (`/clanroll claim`, or
  no rolls left). It's announced in chat, so everyone sees which clan you belong to.

Like vanilla advancements they're announced in chat (the `announceAdvancements` game rule turns that off). Players
who already had jutsu, releases or eyes get those advancements, all at once, the first time they join with this
version.

### Shadow clones
- Clones copy your **hand jutsu**: cast Rasengan, Chidori or Rasenshuriken and each clone gets one too. They
  use Rasengan up close or **throw it** from range, dash in with Chidori, and throw Rasenshuriken.
- While your Sharingan is on, your clones have it too (same stage, they can dodge hits); switch it off and
  theirs goes away.

### Combat tag and vault
- Hitting or being hit by another player (directly, with jutsu or through clones) puts **both** of you in
  combat for 60 seconds: `In Combat (60) - Username` shows at the top of the screen.
- In combat **every command is blocked** (from any mod), and **logging out kills you**; your opponent gets the kill.
- `/vault` opens your personal 54-slot vault. Vault items stay through death.

### Teams
- `/team create <name>`, `/team invite <player>` (they click [Accept]), `/team leave`, `/team kick <name>`,
  `/team disband`, `/team info`. Up to 4 players per team. Your team and who's online show in the stats menu (J).

### Levels and stats
- Gain XP by killing hostile mobs (5 XP each, 100 XP for the first level), from PvP, and from
  **Ninja EXP Bottles** (100 XP each). Update 2 adds quests and bandits.
- **XP Boost Tokens** (1.5x or 2.5x, for 30 minutes or 1 hour): right-click to multiply the XP you earn from
  mobs and PvP. The timer (shown on the HUD) only runs while you're online. A stronger token replaces a
  weaker boost; the same one adds time.
- Each level gives **4 stat points** and **250 Ryo**.
- **Ranks cap your level:** Genin 75, Chunin 150, Jonin 250, Anbu 400, Sannin 500. At the cap, XP is saved
  until you're promoted (by a Kage in Update 2, or `/shinobi rank`).
- Spend points in the stats menu (J); shift-click adds 5. Resetting refunds every point for Ryo
  (500 + 100 per level), with a confirmation screen.
- New players start with a **Frog Wallet** and **3 kunai** (plus the empty Ninjutsu release).

### Jutsu Points and upgrades
- Each level-up has a **35% chance** to give **2-6 Jutsu Points**.
- In the stats menu (J), the **Jutsu** tab lists your learned jutsu that deal damage. **20 points** upgrade one of them
  by **+15% damage**, up to **5 times** (+75%). The bonus applies wherever that jutsu deals damage: Rasengan's punch,
  projectiles, and the copies your shadow clones throw.
- Utility jutsu (Substitution, armors, walls, healing, Shadow Clone itself) can't be upgraded.
- All of the numbers are in the `jutsuUpgrades` config section; `/shinobi jutsupoints` gives points for testing.

| Stat | Effect per point (default) |
|---|---|
| Taijutsu | +0.5 punch damage (bare hand or holding a release) |
| Kenjutsu | +0.4 sword damage |
| Genjutsu | +2% Sharingan dodge/copy range, Amaterasu, Shadow Possession and Yin illusions |
| Medical | +1 max health (half a heart), stronger Yang healing |
| Speed | +1% movement speed (max 50 points, the only capped stat) |
| Ninjutsu | +5 max chakra, slightly faster chakra regen |
| Senjutsu | +10 max natural energy for Sage Mode |

### PvP
- Landing hits on other players gives a little XP (max 30 per minute). Defeating a player gives XP and Ryo,
  more for higher-level opponents.
- **Level-gap rule (both ways):** fights between players whose levels are too far apart give no rewards.
  Strong players get nothing for beating new players, and new players get nothing for beating strong ones
  (so nobody can boost an alt). Anyone can still fight and kill anyone. The allowed gap is the larger of
  10 levels and half the lower player's level: level 1 and level 12+ players get nothing from each other,
  and a level 100 player can be rewarded against levels 50-150.
- No rewards for beating the same player again within 10 minutes, or for killing an AFK player.
  Shadow clone and jutsu kills count as yours. All values are in the `pvp` config section.

### Ryo and the Frog Wallet
- Coins: **Bronze = 100**, **Silver = 500**, **Gold = 1,000** Ryo.
- Right-click the **Frog Wallet**: its mouth opens to show your Ryo and the deposit/withdraw buttons.
  Click the tongue to close it.
- Your Ryo is stored on your player, not in the wallet item. Dropping, losing or copying a wallet never
  loses or duplicates money, and every transfer is checked by the server.

### Ninja weapons
All of them are swords, so Kenjutsu adds to their damage. They live in the **Ninja Tools** creative tab
with the kunai, shuriken and explosive tags. Damage is the number on the tooltip (change it in the
`weapons` config section).

| Weapon | Damage | Speed | Reach | Special |
|---|---|---|---|---|
| Samehada | 34 | 0.7 | +1 | Eats chakra: steals 10 from players you hit, and gives you 5 on every hit |
| Kubikiribocho | 32 | 0.8 | +1 | Repairs itself with every hit |
| Kabutowari (Helmet Splitter) | 26 | 0.8 | +0.5 | **Dual: axe in your hand, hammer in your empty off hand.** Breaks any defence: armor stops 40% less of its damage, and it knocks a raised shield (or a guarding Gunbai) out of use for 5 s |
| Hidan's Triple-Bladed Scythe | 24 | 0.9 | +1.5 | Heals you for 20% of the damage you deal |
| Sword of Fire | 19 | 1.2 | | Sets targets on fire |
| Gunbai | 18 | 1.0 | +1 | **Hold right-click to guard** like a shield: blocks hits from the front, and jutsu and arrows that hit it fly back at whoever threw them. Its swings knock targets back |
| Shakujo Staff | 17 | 1.1 | +1.5 | Heavy knockback |
| Kiba Blades | 16 | 1.9 | | **Dual: a blade in each hand.** Hits spark lightning onto up to 2 nearby enemies for 30% damage (3 chakra). **Right-click** calls lightning down where you look (15 chakra, 8 s cooldown) |
| Kusanagi Sword | 15 | 1.8 | | Chidori Flow: hits spend 4 chakra to paralyse the target |
| Katana | 11 | 1.6 | | |

### Sage Mode
Invest in Senjutsu, then hold **Z** while standing still to gather natural energy (green bar).
Press **B** for Sage Mode: Strength, Resistance, Jump Boost and +25% jutsu damage until the energy runs out.

### Villages and the quest board (Update 2)
Five villages by default: Hidden Leaf (`leaf`), Sand (`sand`), Mist (`mist`), Cloud (`cloud`) and Stone (`stone`).
The list is in the config (`id:Display Name`), so you can rename them or add more.

**Joining a village** is done with permissions (LuckPerms or any permission plugin that works with Forge):

| Permission node | Gives |
|---|---|
| `shinobiarts.village.<id>` | membership, e.g. `shinobiarts.village.leaf` |
| `shinobiarts.village.<id>.kage` | Kage of that village (also counts as a member) |
| `shinobiarts.village.<id>.advisor` | Village Advisor of that village (the player also needs membership) |

Example: `/lp user Steve permission set shinobiarts.village.leaf true`. Membership is re-checked whenever a player
joins or opens the board. Without a permission plugin, operators use `/shinobi village` and `/shinobi kage` (below).

**`/village`** (or `/village <id>`) opens your village's quest board:
- Tabs for **Hourly** (2 quests), **Daily** (3), **Weekly** (2), **Monthly** (1) and **Kage** quests. Random quests
  are rolled for each player when the period starts, and the tab shows when they refresh.
- **Accept** or **Decline** each quest. Only accepted quests count.
- Quest kinds: defeat Ninja Bandits, defeat hostile mobs, defeat enemy players, catch fish, and bring items
  (logs, wheat, bread, iron, diamonds). Item quests complete as soon as you carry the items.
- **Claim** pays the reward (EXP bottles plus Ryo, straight into your wallet balance) and hands the items in:
  **every handed-in item goes to the village storage**, for random quests and Kage quests alike. If the storage
  is full, the quest waits until the Kage makes room.
- The bottom of the board shows the village's **Advisors** ("Need help? Advisors: ..."), online ones in green.

**`/village <id> admin`** opens the **Kage menu** (Kage only):
- **Post a quest**: hold the item you want brought in, then set the amount, EXP bottles and Ryo (capped by the config).
  Every member sees it under the Kage tab. Items handed in for Kage quests go to the village storage.
- **Remove** posted quests (×), **promote or demote** online members (+ / −, Genin → Chunin → Jonin; Anbu only if
  the config allows it).
- **A** appoints (or removes) a **Village Advisor**: the person players should go to when they need help.
  Advisors' names are blue in the member list.
- **Village Storage**: a 54-slot chest shared by the village, opened from the Kage menu.

**Village Advisors** show as **[Advisor]** (and Kages as **[Kage]**) in front of their name in chat and the player
list (turn off with `showTitlesInChat`), on the quest board, and on their own stats page. They come from the Kage
menu, `/shinobi advisor`, or the `.advisor` permission node.

### Ninja Bandits
Rogue ninja who roam the overworld in groups of 1-3, by day and night, anywhere with open sky. Each one uses a
nature: **Fire** (fireballs), **Water** (water bullets) or **Earth** (spikes from the ground under you). The colour
of their scarf and headband shows which. They cast from range and close in with a kunai. They drop 100-400 Ryo in coins
(more with Looting) and sometimes their kunai, and count toward bandit quests. There's a spawn egg in the
Naruto Generations creative tab.

## Recipes (shapeless unless noted)

**Blank Scroll** = 3 paper + stick.

| Item | Recipe |
|---|---|
| Release (e.g. Fire Release) | Blank Scroll + 4 of the release's item (see below) |
| Training Scroll | Blank Scroll + 3 of the nature's item + emerald |
| Elemental jutsu scroll | Blank Scroll + 2 of the nature's item, plus a gold ingot or diamond for the stronger ones (same recipes as before; see `RECIPE_EXTRA` in `tools/make_resources.py`) |
| Clan release jutsu scroll | Blank Scroll + 2 of the release's item; + gold ingot for the B rank, + diamond for the A/S rank |
| Frog Wallet | 2 leather + slime ball + lime dye + string |
| Kubikiribocho (shaped) | 2 iron blocks diagonally above a netherite ingot |
| Samehada (shaped) | heart of the sea, prismarine, netherite ingot on a diagonal (netherite at the bottom) |
| Hidan's Scythe (shaped) | 3 iron blocks across the top, netherite ingot in the middle, stick bottom-left |
| Sword of Fire (shaped) | gold block, netherite ingot, blaze rod on a diagonal (blaze rod at the bottom) |
| Shakujo Staff (shaped) | bell, gold block, gold block on a diagonal (bell at the top) |
| Kusanagi Sword (shaped) | 2 diamonds diagonally above a stick |
| Katana (shaped) | 2 iron ingots diagonally above a stick |
| Kiba Blades (shaped) | lightning rod, diamond block, stick on a diagonal (stick at the bottom) |
| Kabutowari (shaped) | iron axe, netherite ingot, anvil on a diagonal (anvil at the bottom) |
| Gunbai (shaped) | shield, netherite ingot, stick on a diagonal (stick at the bottom) |
| Kunai ×3 (shaped) | iron ingot diagonally above a stick |
| Shuriken ×4 (shaped) | iron ingot in a cross of 4 iron nuggets |
| Explosive Tag ×2 | paper + gunpowder + redstone |
| Chakra Pill ×2 | sugar + sweet berries + glowstone dust |
| Chakra Paper ×2 | paper + lapis lazuli |

Nature items: Fire = blaze powder, Water = prismarine shard, Wind = feather, Lightning = copper ingot,
Earth = clay ball, Yin Yang = amethyst shard, Ninjutsu = lapis lazuli, Wood = oak sapling, Ice = packed ice,
Magnet = iron nugget, Bone = bone, Sealing = chain.
Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon; Ninjutsu and clan jutsu have special
recipes (see `tools/make_resources.py`).

## Admin commands (operators)

```
/shinobi info [player]
/shinobi xp <player> <amount>
/shinobi level <player> <level>
/shinobi rank <player> <genin|chunin|jonin|anbu|sannin>
/shinobi ryo <player> add|set <amount>
/shinobi release <player> <fire|water|wind|lightning|earth|yin_yang|ninjutsu>
/shinobi learn <player> <jutsu|all>        /shinobi forget <player> <jutsu|all>
/shinobi nature <player> <nature>          /shinobi clan <player> <clan>   (any of the 30; see /clan list)
/shinobi clanroll <player> reset           (gives a player their /clanroll uses back and unclaims their clan)
/shinobi refill <player>                   /shinobi reset <player>
/shinobi sharingan <player> <0-4>          (0 none, 1-3 tomoe, 4 Mangekyou)
/shinobi mangekyou <player> <itachi|sasuke|obito|eternal>   (gives the Mangekyou in that pattern)
/shinobi village <player> <village|none>   (puts a player in a village without a permission plugin)
/shinobi kage <player> <village|none>      (makes a player Kage; "none" removes the Kage title)
/shinobi advisor <player> <village|none>   (makes a player a Village Advisor; "none" removes it)
/shinobi jutsupoints <player> add|set <amount>
```

Everyone: `/clanroll`, `/clanroll claim`, `/vault`, `/team ...`, `/village`, `/village list`, `/clan`, `/clan list`, `/clan info <clan>`
(all blocked while in combat). XP Boost Tokens have no recipe yet: hand them out
with `/give <player> shinobiarts:xp_boost_2_5x_60m` (or `_1_5x_30m`, `_1_5x_60m`, `_2_5x_30m`).

Susanoo test: `/shinobi rank @s sannin`, `/shinobi level @s 250`, `/shinobi mangekyou @s eternal`, switch your eyes on
(**V**), then press **O** five times.

Quick test: `/shinobi learn @s all`, `/shinobi rank @s sannin`, `/shinobi level @s 20`, `/shinobi ryo @s add 5000`,
`/shinobi release @s fire`.

## Config

Each world has a `saves/<world>/serverconfig/Naruto Generations/` folder with `Jutsus.toml`, `Weapons.toml`,
`Food.toml`, `Stats.toml`, `Spawn weights and chances.toml` and `General.toml`, and servers send them to every player
who joins. Together they hold XP curve, rank level caps, points and Ryo per level, every stat's value per point, the Speed cap,
reset cost, chakra regen, Senjutsu rates, Ninja Jump cost/power, damage and cooldown
multipliers, jutsu griefing, PvP rewards, each weapon's damage and special effect strength, jutsu chakra cost,
rank level requirements, mob XP, Sharingan stage levels and near-death health, eye theft, combat tag length,
command blocking, combat-log kills, team size, the village list, how many hourly/daily/weekly/monthly quests each
player gets, the Kage's reward caps and quest limit, whether a Kage can promote to Anbu, and the bandits' Ryo
drops and jutsu damage, how many times each player can use /clanroll, the chance of each clan rarity tier and whether rare rolls are announced, Jutsu Point chance/amount, upgrade cost, damage per upgrade and max upgrades, and whether
[Kage]/[Advisor] titles show in chat, every eye technique's cost, cooldown and range (`eyeTechniques`), Substitution's
jump and logs (`jutsuTuning`), and Chakra Control's drain and climb speed (`chakraControl`). Ninja Bandit spawning
(weight 10, groups of 1-3, all overworld biomes) and the DNA and kekkei genkai scroll drops are in
`Spawn weights and chances.toml` (spawning changes need a restart).

## Art and models

- The Fire/Water/Wind/Lightning/Earth emblems, Amaterasu's black flames, the Great Fireball and Water Bullet sprites,
  Lightning Armor's sparks and the Sasuke/Obito/Eternal Mangekyou irises come from your asset pack
  (`tools/source_art/jutsu` and `tools/source_art/sharingan`). `python3 tools/import_jutsu_art.py` brings them in and
  also draws the Kamui/Genjutsu icons and the grey Sharingan of the empty dojutsu slot; then
  `python3 tools/make_sharingan.py` puts the Mangekyou patterns on the faces and the screen flash.
- The clan release emblems (木 氷 磁 骨 封) are drawn by `python3 tools/make_clan_releases.py`, in the same octagon
  style. Their blocks use vanilla textures (oak log, packed ice, black concrete powder, bone block).
- **The Yin Yang and Ninjutsu icons are placeholders.** To replace one, save a square PNG as
  `src/main/resources/assets/shinobiarts/textures/nature/<yin_yang|ninjutsu>.png`, create an empty file
  `.<name>.provided` next to it, and run `python3 tools/make_textures.py` to rebuild the item icons.
- 3D models come from `tools/source_art/*.glb` and `tools/source_art/weapons/*.obj` (with their textures).
  `python3 tools/convert_models.py` turns them into Forge OBJ models: kunai, shuriken, the weapons, and the
  jutsu, training (地) and blank scrolls. The shuriken uses `source_art/shuriken_metal.png` because its own
  color is nearly black.
  `python3 tools/recolor_scrolls.py` then makes the jutsu scroll's color for each release.
  Samehada uses `source_art/samehada_recolor.png` (blue shark-skin scales, off-white bandages, blue grip), made by
  `python3 tools/recolor_samehada.py`. Its model tiles its texture, which Minecraft can't do, so the converter
  moves every triangle's texture coordinates back into range (that was what made it look glitchy).
  Each item holds exactly one scroll. The size of each weapon is its `length` in `MODELS`.
  Kiba, Kabutowari (axe and hammer, without the chain) and the Gunbai come from `tools/source_art/kiba.glb`,
  `kabutowari.glb` and `gunbai.glb`; their in-hand sizes are in `WEAPONS` / `OFFHAND_MODELS` in `tools/make_resources.py`.
- `python3 tools/make_jutsu_models.py` turns `tools/source_art/rasengan.glb` and `earth_spike_cluster.bbmodel` into the
  Rasengan and Rising Spikes meshes (`assets/shinobiarts/meshes/`) and their textures.
- `python3 tools/make_headbands.py` draws the forehead protector plates from the height maps of Calfan's headband model
  (`tools/source_art/headbands/`), plus the cloth and the inventory icons.
- Inventory icons stay flat so they're easy to read; the 3D model shows in your hand, on the ground and in flight.
  The kunai, shuriken, weapon and scroll icons are rendered from their 3D models
  (`tools/convert_models.py`, then `tools/recolor_scrolls.py` for the scroll colors).
- The chakra figure on the HUD is `source_art/chakra_figure.png` (cut out of your picture), saved small as
  `textures/gui/chakra_figure.png`. All Sharingan art (eyes on faces for each stage and pattern, the screen flash,
  the item icons, and the HUD's round eye icons) is drawn by `tools/make_sharingan.py`; the XP token icons
  by `tools/make_tokens.py`.
- Above the HUD scroll sits a row of slots: your eyes (Sharingan at its stage and pattern, or Byakugan, bright with a
  red or violet frame while active), the four armor pieces you're wearing with durability bars, and your eye
  techniques with their keys and cooldowns.

## Credits

These models are used under their Creative Commons licences (CC BY 4.0 unless noted), from Sketchfab:

| Model | Artist | Used for |
|---|---|---|
| Kiba | Nelesh_surve (sketchfab.com/Nelesh_surve) | Kiba Blades |
| Helmet Splitter (Kabutowari) - Naruto | Xnropa (sketchfab.com/sm3n26) | Kabutowari's axe and hammer |
| Gunbai Uchiwa | DontQuitIdol (sketchfab.com/fg2011) | Gunbai |
| Partical rasengan | OPREXT (sketchfab.com/OPREXT) | Rasengan |
| Naruto Headbands (CC BY-NC 4.0) | Calfan (sketchfab.com/Calfan) | Forehead protector plates |
| Zabuza Sword - Kubikiribocho | Ziof (sketchfab.com/fabri_iorio) | Kubikiribocho |
| Naruto Shippuden - Samehada | XDaniXSin (sketchfab.com/XDaniXSin) | Samehada (recoloured) |
| kunai | DMI (sketchfab.com/lord_DMI) | Kunai |
| Shuriken T0 | Clayton Creative (sketchfab.com/clayton_creative) | Shuriken (retextured) |
| Scrolls from Naruto | Viggo (sketchfab.com/Viggoa) | Jutsu, training and blank scrolls (recoloured) |

The models were converted for Minecraft (resized, posed for holding, textures baked or recoloured where noted).
The forehead protector plates are under a non-commercial licence, so this mod must not be sold or monetised while it
uses them. The Earth Flow Spike Cluster model was made for this mod.

## Saves

All player data lives in one place (`ninja/NinjaData.java`, changed only through
`ninja/PlayerDataManager.java`). It has a `DataVersion`; saves from the first version are upgraded
automatically: learned jutsu are kept, and old chakra training becomes stat points.

## Project layout

```
src/main/java/com/shinobiarts/
  ninja/      player data (NinjaData), PlayerDataManager, clans, natures, stats
  jutsu/      jutsu list, effects, casting, per-tick logic, key actions
  item/       releases, jutsu/training scrolls, coins, wallet, EXP bottle, weapons
  entity/     jutsu projectiles, thrown weapons, explosive tags, shadow clones
  client/     HUD, stats/reset/wallet screens, keybinds, renderers
  network/    key/menu requests (client -> server) and data sync (server -> client)
  command/    /shinobi
tools/        generators for icons, 3D models, models/recipes/lang (run with Python 3)
```
